<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
?>

<div class="card">
	<div class="card-header d-flex justify-content-between align-items-center" style="font-size: 18px">
		Spam Chuyển Tiền
	</div>
	<div class="card-body">
		<div class="d-flex justify-content-center align-items-center mb-3">
			<button type="button" class="btn btn-primary mx-auto"><i class="fas fa-user" style="vertical-align: -2px;"></i> Tất cả người chơi</button>
		</div>
		<div class="form-group">
			<label for="exampleInputEmail1">Số Điện Thoại</label>
			<select class="form-control" name="momo_account" id="momo_account">
			<?php
				$req = $db->Query("SELECT * FROM `tb_private_momo`");
				while ($row = mysqli_fetch_array($req)) 
				{
					echo '<option value="'.$row['phone'].'">'.$row['phone'].' - '.number_format($row['balance']).' VND</option>';
				}
			?>
			</select>
		</div>
		<div class="form-group">
			<label for="nofication_ex">Người Nhận</label>
			<textarea class="form-control" id="nofication_ex" name="nofication_ex" placeholder="Nhập số điện thoại người nhận mỗi số 1 dòng" rows="3"></textarea>
		</div>
		<div class="form-group">
			<label for="title">Số Tiền</label>
			<input type="text" class="form-control" name="title" id="title" value="" placeholder="100">
		</div>
		<div class="form-group">
			<label for="nofication_ex">Nội Dung</label>
			<textarea class="form-control" id="nofication_ex" name="nofication_ex" placeholder="Nhập nội dung cần chuyển, random thì nhập nhiều dòng" rows="3"></textarea>
		</div>
		<div class="d-flex justify-content-center align-items-center mb-3">
			<button type="button" class="btn btn-primary mx-auto"><i class="fas fa-plus-circle" style="vertical-align: -2px;"></i> Tiến hành</button>
		</div>
	</div>
</div>