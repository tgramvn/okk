<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
?>

<div class="card">
	<div class="card-header" style="font-size: 18px">
		Quản Lý Mini Game
	</div>
	<div class="card-body">
		<div class="table-responsive mb-3">
			<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center" id="txnTable">
				<thead>
					<tr class="badge-primary text-white">
						<th class="text-center text-white">LOẠI</th>
						<th class="text-center text-white">TÊN MINI GAME</th>
						<th class="text-center text-white">MÔ TẢ</th>
						<th class="text-center text-white">CÚ PHÁP</th>
						<th class="text-center text-white">TỶ LỆ</th>
						<th class="text-center text-white">TRƯNG BÀY</th>
						<th class="text-center text-white">HÀNH ĐỘNG</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$reqs = $db->Query("SELECT * FROM `tb_game`");
						while ($row = mysqli_fetch_array($reqs))
						{
							if ($row['enable'] == 0) { $enable = '<span class="badge badge-warning p-1">Không Hiển Thị</span>'; }
							if ($row['enable'] == 1) { $enable = '<span class="badge badge-success p-1">Hiển Thị</span>';  }
					?>
					<tr>
						<td class="text-center">
							<span class="badge badge-info p-1"><?php echo $row['gameType']; ?></span>
						</td>
						<td class="text-center"><?php echo $row['gameName']; ?></td>
						<td class="text-center">
							<textarea class="form-control" name="description" id="description" data-id="<?php echo $row['id']; ?>" rows="2"><?php echo $row['description']; ?></textarea>
						</td>
						<td class="text-center">
							<input type="text" class="form-control w-full" name="content" id="content" data-id="<?php echo $row['id']; ?>" value="<?php echo $row['content']; ?>">
						</td>
						<td class="text-center">
							<input type="text" class="form-control w-full" name="amount" id="amount" data-id="<?php echo $row['id']; ?>" value="<?php echo $row['amount']; ?>">
						</td>
						<td class="text-center">
							<?php echo $enable; ?>
						</td>
						<td class="text-center">
							<button class="btn btn-primary btn-sm mr-2 py-2" href="#" onclick="updateAmount(this)" data-id="<?php echo $row['id']; ?>">
                            	<i class="fal fa-save" style="vertical-align: -2px; width: 1rem"></i>
                            </button>
							<?php if ($row['enable'] == 1) { ?>
							<button class="btn btn-success btn-sm mr-2 py-2" href="#" onclick="hideGame(this)" data-id="<?php echo $row['id']; ?>">
                            	<i class="fal fa-eye" style="vertical-align: -2px; width: 1.2rem"></i>
                            </button>
							<?php } else { ?>
							<button class="btn btn-danger btn-sm mr-2 py-2" href="#" onclick="showGame(this)" data-id="<?php echo $row['id']; ?>">
                            	<i class="fal fa-eye-slash" style="vertical-align: -2px; width: 1.2rem"></i>
                            </button>

							<?php } ?>
						</td>
					</tr>
					<?php
						}
					?>

				</tbody>
			</table>
		</div>
	</div>
</div>
<script type="text/javascript">

	function updateAmount(data) {
		$.ajax({
			url: 'admin/api/game.php?act=update',
			type: 'POST',
			dataType: 'json',
			data: {
				id: $(data).data('id'),
				description: $('[id="description"][data-id="' + $(data).data('id') + '"]').val(),
				content: $('[id="content"][data-id="' + $(data).data('id') + '"]').val(),
				amount: $('[id="amount"][data-id="' + $(data).data('id') + '"]').val()
			},
			beforeSend: function(){
			},
			success: function (response) {
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
				if (response.status == true) {
					$('.modal-backdrop').remove();
					loadFileFormUrl("admin/game");
				}
			},
			error: function (error) {
				console.log(error);
			}
		});

	}

	function hideGame(data) {
		$.ajax({
			url: 'admin/api/game.php?act=hide',
			type: 'POST',
			dataType: 'json',
			data: {
				id: $(data).data('id'),
			},
			beforeSend: function(){
			},
			success: function (response) {
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
				if (response.status == true) {
					$('.modal-backdrop').remove();
					loadFileFormUrl("admin/game");
				}
			},
			error: function (error) {
				console.log(error);
			}
		});
	}

	function showGame(data) {
		$.ajax({
			url: 'admin/api/game.php?act=show',
			type: 'POST',
			dataType: 'json',
			data: {
				id: $(data).data('id'),
			},
			beforeSend: function(){
			},
			success: function (response) {
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
				if (response.status == true) {
					$('.modal-backdrop').remove();
					loadFileFormUrl("admin/game");
				}
			},
			error: function (error) {
				console.log(error);
			}
		});
	};
</script>