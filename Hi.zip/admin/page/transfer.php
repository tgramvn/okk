<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
?>

<div class="card">
	<div class="card-header" style="font-size: 18px">
		Chuyển Tiền
	</div>
	<div class="card-body">
		<div class="form-group">
			<label for="exampleInputEmail1">Số Điện Thoại</label>
			<select class="form-control" name="momo_account" id="momo_account">
			<?php
				$req = $db->Query("SELECT * FROM `tb_private_momo`");
				while ($row = mysqli_fetch_array($req)) 
				{
					echo '<option value="'.$row['phone'].'">'.$row['phone'].' - '.number_format($row['balance']).' VND</option>';
				}
			?>
			</select>
		</div>
		<div class="form-group">
			<label for="phone">Người Nhận</label>
			<input type="text" class="form-control" name="phone" id="phone" placeholder="Nhập số người nhận">
		</div>
		<div class="form-group">
			<label for="cash">Số Tiền</label>
			<input type="text" class="form-control" name="cash" id="cash" placeholder="Nhập số tiền">
		</div>
		<div class="form-group">
			<label for="content">Nội dung</label>
			<input type="text" class="form-control" name="content" id="content" value="Chuyển từ web">
		</div>
		<div class="form-group">
			<label for="password">Mật khẩu tài khoản Admin</label>
			<input type="password" class="form-control" name="password" id="password" placeholder="Nhập mật khẩu">
		</div>
		<div class="d-flex justify-content-center align-items-center">
			<button type="button" onclick="momoTransfer(this)" class="btn btn-primary mx-auto"><i class="far fa-exchange"></i> Chuyển Tiền</button>
		</div>
	</div>
</div>
<script type="text/javascript">
	function momoTransfer(data)
	{
		$.ajax({
			url: 'admin/api/transfer.php',
			type: 'POST',
			dataType: 'json',
			data: {
				momo_account : $('#momo_account').val(),
				content : $('#content').val(),
				phone : $('#phone').val(),
				cash : $('#cash').val(),
				password : $('#password').val()
			},
			success: function(response)
			{
				if (response.status == false) {
					SwalAlert(
						response.message,
						response.status == true ? "success" : "error"
					);
				} else {
					loadFileFormUrl("admin/transfer-history");
				}
			}
		});
	}
</script>