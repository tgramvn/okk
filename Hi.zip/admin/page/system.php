<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
?>

<div class="card">
	<div class="card-header" style="font-size: 18px">
		Cài Đặt Hệ Thống
	</div>
	<div class="card-body">
		<form id="settingForm" name="settingForm" method="POST" action="admin/api/setting.php">
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="website_name">Tên Website</label>
						<input type="text" class="form-control" name="website_name" id="website_name" placeholder="" value="<?php echo $core->isHomeSetting('website_name'); ?>">
					</div>
					<div class="form-group">
						<label for="favicon">Icon Website</label>
						<input type="text" class="form-control" name="favicon" id="favicon" value="<?php echo $core->isHomeSetting('favicon'); ?>">
					</div>
					<div class="form-group">
						<label for="description">Mô Tả</label>
						<textarea class="form-control" name="description" id="description" rows="3"><?php echo $core->formatExportDatabase($core->isHomeSetting('description')); ?></textarea>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="title">Tiêu Đề</label>
						<input type="text" class="form-control" name="title" id="title" value="<?php echo $core->formatExportDatabase($core->isHomeSetting('title')); ?>">
					</div>
					<div class="form-group">
						<label for="og:image">Thumbnail Website</label>
						<input type="text" class="form-control" name="og:image" id="og:image" value="<?php echo $core->formatExportDatabase($core->isHomeSetting('og:image')); ?>">
					</div>
					<div class="form-group">
						<label for="keywords">Keywords</label>
						<textarea class="form-control" name="keywords" id="keywords" rows="3"><?php echo $core->formatExportDatabase($core->isHomeSetting('keywords')); ?></textarea>
					</div>
				</div>

				<div class="col-md-12">
					<div class="form-group">
						<label for="support_link">Footer Script Support</label>
						<textarea class="form-control" name="support_link" id="support_link" rows="3"><?php echo $core->formatExportDatabase($core->isHomeSetting('support_link')); ?></textarea>
					</div>
				</div>

				<div class="col-md-12">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="support_telegram_account">Xử Lý Đơn Telegram</label>
								<input type="text" class="form-control" name="support_telegram_account" id="support_telegram_account" value="<?php echo $core->isHomeSetting('support_telegram_account'); ?>">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="support_telegram_group">Group Telegram</label>
								<input type="text" class="form-control" name="support_telegram_group" id="support_telegram_group" value="<?php echo $core->isHomeSetting('support_telegram_group'); ?>">
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-12">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="bot_autogame">BOT AutoGame</label>
								<select class="form-control" name="bot_autogame" id="bot_autogame">
									<option value="On"<?php if ($core->isHomeSetting('bot_autogame') == 'On') { echo 'selected'; } ?>>Bật</option>
									<option value="Off"<?php if ($core->isHomeSetting('bot_autogame') == 'Off') { echo 'selected'; } ?>>Tắt</option>
								</select>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="bot_automuster">BOT AutoMuster</label>
								<select class="form-control" name="bot_automuster" id="bot_automuster">
									<option value="On"<?php if ($core->isHomeSetting('bot_automuster') == 'On') { echo 'selected'; } ?>>Bật</option>
									<option value="Off"<?php if ($core->isHomeSetting('bot_automuster') == 'Off') { echo 'selected'; } ?>>Tắt</option>
								</select>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-12">
					<div class="form-group">
						<label for="top_day_virtual">Phần Thưởng Mốc</label>
						<div class="table-responsive mb-3">
							<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center">
								<thead>
									<tr class="badge-primary text-white">
										<th class="text-center text-white">VỊ TRÍ</th>
										<th class="text-center text-white">MỐC CHƠI</th>
										<th class="text-center text-white">TIỀN THƯỞNG</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$pamount = explode("|", $core->isHomeSetting('top_day_player_amount'));
									$pbonus = explode("|", $core->isHomeSetting('top_day_player_bonus'));
									for ($i = 1; $i <= 4; $i++)
									{
										$day_amount = (empty($pamount)) ? '0' : $pamount[$i];
										$day_bonus = (empty($pbonus)) ? '0' : $pbonus[$i];
									?>
									<tr>
										<td class="text-center"><?php echo $i; ?></td>
										<td class="text-center"><input type="text" class="form-control" name="player_amount_<?php echo $i; ?>" id="player_amount_<?php echo $i; ?>" value="<?php echo $day_amount; ?>"></td>
										<td class="text-center"><input type="text" class="form-control" name="player_bonus_<?php echo $i; ?>" id="player_bonus_<?php echo $i; ?>" value="<?php echo $day_bonus; ?>"></td>
									</tr>
								    <?php
									}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>

				<div class="col-md-12">
					<div class="form-group">
						<label for="top_day">Top Thưởng Ngày</label>
						<div class="row">
							<?php
							$top_day = explode("|", $core->isHomeSetting('top_day'));
							for ($i = 1; $i <= 6; $i++)
							{
								$top_day_result = (empty($top_day)) ? '0' : $top_day[$i];
							?>
							<div class="col-md-2">
								<input type="text" class="form-control" name="tops_day_<?php echo $i; ?>" id="tops_day_<?php echo $i; ?>" value="<?php echo $top_day_result; ?>">
							</div>
							<?php } ?>
						</div>
					</div>

					<div class="form-group">
						<label for="top_day_virtual">Top Ảo</label>
						<select class="form-control" name="top_day_virtual" id="top_day_virtual">
							<option value="On"<?php if ($core->isHomeSetting('top_day_virtual') == 'On') { echo 'selected'; } ?>>Bật</option>
							<option value="Off"<?php if ($core->isHomeSetting('top_day_virtual') == 'Off') { echo 'selected'; } ?>>Tắt</option>
						</select>
					</div>
					<div class="form-group">

						<div class="table-responsive mb-3">
							<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center">
								<thead>
									<tr class="badge-primary text-white">
										<th class="text-center text-white">VỊ TRÍ</th>
										<th class="text-center text-white">TIỀN THẮNG</th>
										<th class="text-center text-white">TIỀN THƯỞNG</th>
										<th class="text-center text-white">SỐ ĐIỆN THOẠI</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$twin = explode("|", $core->isHomeSetting('top_day_virtual_win'));
									$tamount = explode("|", $core->isHomeSetting('top_day_virtual_amount'));
									$tphone = explode("|", $core->isHomeSetting('top_day_virtual_phone'));
									$num = 1;
									for ($i = 1; $i <= 5; $i++)
									{
										$ck_win = (empty($twin)) ? '0' : $twin[$i];
										$ck_amount = (empty($tamount)) ? '0' : $tamount[$i];
										$ck_phone = (empty($tphone)) ? '0' : $tphone[$i];
									?>
									<tr>
										<td class="text-center"><?php echo $num; ?></td>
										<td class="text-center"><input type="text" class="form-control" name="virtual_win_<?php echo $i; ?>" id="virtual_win_<?php echo $i; ?>" value="<?php echo $ck_win; ?>"></td>
										<td class="text-center"><input type="text" class="form-control" name="virtual_amount_<?php echo $i; ?>" id="virtual_amount_<?php echo $i; ?>" value="<?php echo $ck_amount; ?>"></td>
										<td class="text-center"><input type="text" class="form-control" name="virtual_phone_<?php echo $i; ?>" id="virtual_phone_<?php echo $i; ?>" value="<?php echo $ck_phone; ?>"></td>
									</tr>
								    <?php
								    $num++;
									}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>


				<div class="col-md-12">
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label for="refund">Hoàn Tiền</label>
								<select class="form-control" name="refund" id="refund">
									<option value="Yes" <?php if ($core->isHomeSetting('refund') == 'Yes') { echo 'selected'; } ?>>Có</option>
									<option value="No" <?php if ($core->isHomeSetting('refund') == 'No') { echo 'selected'; } ?>>Không</option>
								</select>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="refund_win">Thắng Hoàn %</label>
								<input type="text" class="form-control" name="refund_win" id="refund_win" value="<?php echo $core->isHomeSetting('refund_win'); ?>">
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="refund_lose">Thua Hoàn %</label>
								<input type="text" class="form-control" name="refund_lose" id="refund_lose" value="<?php echo $core->isHomeSetting('refund_lose'); ?>">
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="refund_maximum">Giới hạn hoàn</label>
								<input type="text" class="form-control" name="refund_maximum" id="refund_maximum" value="<?php echo $core->isHomeSetting('refund_maximum'); ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="jackpot">Nổ Hũ</label>
								<select class="form-control" name="jackpot" id="jackpot">
									<option value="Yes"<?php if ($core->isHomeSetting('jackpot') == 'Yes') { echo 'selected'; } ?>>Có</option>
									<option value="No"<?php if ($core->isHomeSetting('jackpot') == 'No') { echo 'selected'; } ?>>Không</option>
								</select>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="jackpot_amount">Tiền Hũ</label>
								<input type="text" class="form-control" name="jackpot_amount" id="jackpot_amount" value="<?php echo $core->isHomeSetting('jackpot_amount'); ?>">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="jackpot_code">Mã Nổ Hũ</label>
								<input type="text" class="form-control" name="jackpot_code" id="jackpot_code" value="<?php echo $core->isHomeSetting('jackpot_code'); ?>">
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="jackpot_amount_minus">Tiền Trừ Hũ</label>
								<input type="text" class="form-control" name="jackpot_amount_minus" id="jackpot_amount_minus" value="<?php echo $core->isHomeSetting('jackpot_amount_minus'); ?>">
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label for="muster_start">Bắt Đầu (MUSTER)</label>
								<input type="text" class="form-control" name="muster_start" id="muster_start" value="<?php echo $core->isHomeSetting('muster_start'); ?>">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="muster_end">Kết Thúc (MUSTER)</label>
								<input type="text" class="form-control" name="muster_end" id="muster_end" value="<?php echo $core->isHomeSetting('muster_end'); ?>">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="muster_time">Thời Gian (MUSTER)</label>
								<input type="text" class="form-control" name="muster_time" id="muster_time" value="<?php echo $core->isHomeSetting('muster_time'); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="muster_money_start">Số tiền tối thiểu (MUSTER)</label>
								<input type="text" class="form-control" name="muster_money_start" id="muster_money_start" value="<?php echo $core->isHomeSetting('muster_money_start'); ?>">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="muster_money_end">Số tiền tối đa (MUSTER)</label>
								<input type="text" class="form-control" name="muster_money_end" id="muster_money_end" value="<?php echo $core->isHomeSetting('muster_money_end'); ?>">
							</div>
						</div>

					</div>
				</div>

				<div class="col-md-12">
					<div class="form-group">
						<label for="muster_ex">Lưu ý Muster</label>
						<textarea class="form-control muster" name="muster_ex" id="muster_ex" rows="3"><?php echo $core->formatExportDatabase($core->isHomeSetting('muster_ex')); ?></textarea>
					</div>
					<div class="form-group">
						<label for="nofication">Thông Báo</label>
						<select class="form-control" name="nofication" id="nofication">
							<option value="On"<?php if ($core->isHomeSetting('nofication') == 'On') { echo 'selected'; } ?>>Bật</option>
							<option value="Off"<?php if ($core->isHomeSetting('nofication') == 'Off') { echo 'selected'; } ?>>Tắt</option>
						</select>
					</div>
					<div class="form-group">
						<label for="nofication_ex">Nội Dung Thông Báo</label>
						<textarea class="form-control notification" id="nofication_ex" name="nofication_ex" rows="3"><?php echo $core->formatExportDatabase($core->isHomeSetting('nofication_ex')); ?></textarea>
					</div>
					<div class="form-group">
						<label for="alert">Lưu ý</label>
						<textarea class="form-control i-alert" name="alert" id="alert" rows="3"><?php echo $core->formatExportDatabase($core->isHomeSetting('alert')); ?></textarea>
					</div>
				</div>
			</div>
			<button type="submit" name="submit" class="btn btn-primary w-100">Lưu</button>
		</form>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function() {
		initFormAjax("#settingForm", function(e){
            loadFileFormUrl("admin/system");
        });
        $('.muster').richText();
        $('.notification').richText();
        $('.i-alert').richText();
    });
</script>