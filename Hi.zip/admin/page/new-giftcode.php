<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
$total_amount = mysqli_fetch_assoc($db->Query("SELECT SUM(`balance`) FROM `tb_private_momo`"))['SUM(`balance`)'];
?>

<div class="card">
	<div class="card-header d-flex justify-content-between align-items-center" style="font-size: 18px">
		Quản Lý GiftCode V2
		<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#AddGift"><i class="fas fa-plus-circle" style="vertical-align: -2px;"></i></button>
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-md-10">
				<div class="form-group">
            		<input type="text" class="form-control" name="search_data" id="search_data" value="" placeholder="Nhập nội dung tìm kiếm">
            	</div>
			</div>
			<div class="col-md-2">
				<button type="button" class="btn btn-primary" onclick="Search()">
					<i class="fas fa-search" style="vertical-align: -2px;"></i>
				</button>
				<button type="button" class="btn" onclick="ResetDataTable()">
					<i class="fas fa-times-circle" style="vertical-align: -2px; color: red"></i>
				</button>
			</div>
		</div>
		<div class="table-responsive mb-3">
			<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center" id="GiftCodeTable">
				<thead>
					<tr class="badge-primary text-white">
						<th class="text-center text-white px-5">ID</th>
						<th class="text-center text-white">GIFTCODE</th>
						<th class="text-center text-white">MỆNH GIÁ</th>
						<th class="text-center text-white">LƯỢT SỬ DỤNG CÒN LẠI</th>
						<th class="text-center text-white">NGÀY TẠO</th>
						<th class="text-center text-white">NGÀY HẾT HẠN</th>
						<th class="text-center text-white">TRẠNG THÁI</th>
						<th class="text-center text-white">HÀNH ĐỘNG</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$i = 1;
						$req = $db->Query("SELECT * FROM `tb_giftcode_cash`");
						while ($row = mysqli_fetch_array($req))
						{
							if ($row['state_at'] == 'active') { $stat = '<span class="badge badge-success p-1">Chưa sử dụng</span>'; }
							if ($row['state_at'] == 'dead-active') { $stat = '<span class="badge badge-danger p-1">Đã sử dụng</span>';  }
					?>
					<tr>
						<td class="text-center"><?php echo $i; ?></td>
						<td class="text-center"><?php echo $row['code']; ?></td>
						<td class="text-center"><?php echo number_format($row['amount']); ?>đ</td>
						<td class="text-center"><?php echo $row['count']; ?></td>
						<td class="text-center"><?php echo date("d-m-Y H:i:s", $row['created_at']); ?></td>
						<td class="text-center"><?php echo date("d-m-Y H:i:s", $row['expired_at']); ?></td>
						<td class="text-center"><?php echo $stat; ?></td>
						<td class="text-center">
                            <button class="btn btn-danger btn-sm py-2" href="#" onclick="RemoveGift(<?php echo $row['id']; ?>)">
                            	<i class="fal fa-trash-alt" style="vertical-align: -2px; width: 1rem"></i>
                            </button>
                        </td>
					</tr>
					<?php
							$i++;
						}
					?>

				</tbody>
			</table>
		</div>
	</div>
</div>

<div class="modal fade" id="AddGift" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Thêm mã GiftCode</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            	<div class="form-group">
            		<label for="amount">Mệnh giá</label>
            		<input type="text" class="form-control" name="amount" id="amount" value="">
            	</div>
            	<div class="form-group">
            		<label for="count">Số lần sử dụng</label>
            		<input type="text" class="form-control" name="count" id="count" value="1">
            	</div>
            	<div class="form-group">
            		<label for="exp">Ngày hết hạn</label>
            		<select class="form-control" name="exp" id="exp">
            			<option value="1">1 Ngày</option>
            			<option value="3">3 Ngày</option>
            			<option value="7">7 Ngày</option>
            			<option value="15">15 Ngày</option>
            			<option value="30">1 Tháng</option>
            		</select>
            	</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-block" onclick="AddGiftCodeEvent()">Thêm</button>
            </div>
        </div>
    </div>
</div>

<style type="text/css">
	.dataTables_wrapper .dataTables_info,
	.dataTables_wrapper .dataTables_paginate {
		margin-top: 10px !important;
	}

	div.dataTables_wrapper div.dataTables_paginate ul.pagination {
		justify-content: center !important;
	}

</style>
<script type="text/javascript">
	$(document).ready(function (e){
		var datatable = $('#GiftCodeTable').DataTable({
			ordering: false,
			lengthChange: false,
			dom: 'rtp',
			searching: true,
			responsive: false,
			pageLength: 25,
			language: {
				info: "Hiển thị _START_-_END_ của _TOTAL_ kết quả.",
				infoEmpty: "Không có dữ liệu hiển thị!",
				zeroRecords: '<div class="text-center" style="margin-top: 10px"><img src="../assets/images/photos/404.png"><p class="font-weight-bold">Không tìm thấy dữ liệu...</p></div>'
			}
		});
	});

	function Search()
	{
		var search_data = $("#search_data").val();
		$('#GiftCodeTable').DataTable().search(search_data, false, false).draw();
	}

	function ResetDataTable()
	{
		$("#search_data").val("")
		$('#GiftCodeTable').DataTable().search("").draw(); 
	}

	function AddGiftCodeEvent()
	{
		$.ajax({
			url: 'admin/api/new-giftcode.php?act=create',
			type: 'POST',
			dataType: 'json',
			data: {
				amount : $('#amount').val(),
				count : $('#count').val(),
				exp : $('#exp').val()
			},
			success: function(response)
			{
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
				if (response.status == true) {
					$('.modal-backdrop').remove();
					loadFileFormUrl("admin/new-giftcode");
				}
			}
		});
	}

	function RemoveGift(data)
	{
		Swal.fire({
            title: 'Thông báo',
            text: "Bạn muốn xóa GiftCode này?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#BF3238',
            confirmButtonText: 'Xoá ngay',
        }).then((result) => {
            if (result.isConfirmed) {
				$.ajax({
					url: 'admin/api/new-giftcode.php?act=delete',
					type: 'POST',
					dataType: 'json',
					data: {
						id : data
					},
					success: function(response)
					{
						SwalAlert(
							response.message,
							response.status == true ? "success" : "error"
						);
						if (response.status == true) {
							$('.modal-backdrop').remove();
							loadFileFormUrl("admin/new-giftcode");
						}
					}
				});
			}
        });
	}

</script>