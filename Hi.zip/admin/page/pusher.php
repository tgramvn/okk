<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
?>

<div class="card">
	<div class="card-header d-flex justify-content-between align-items-center" style="font-size: 18px">
		Danh Sách Tài Khoản Thông Báo
		<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addPusherAccount"><i class="fas fa-plus-circle" style="vertical-align: -2px;"></i></button>
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-md-10">
				<div class="form-group">
            		<input type="text" class="form-control" name="search_data" id="search_data" value="" placeholder="Nhập nội dung tìm kiếm">
            	</div>
			</div>
			<div class="col-md-2">
				<button type="button" class="btn btn-primary" onclick="Search()">
					<i class="fas fa-search" style="vertical-align: -2px;"></i>
				</button>
				<button type="button" class="btn" onclick="ResetDataTable()">
					<i class="fas fa-times-circle" style="vertical-align: -2px; color: red"></i>
				</button>
			</div>
		</div>
		<div class="table-responsive mb-3">
			<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center" id="PusherAccountTable">
				<thead>
					<tr class="badge-primary text-white">
						<th class="text-center text-white px-5">ID</th>
						<th class="text-center text-white">APP ID</th>
						<th class="text-center text-white">CLUSTER</th>
						<th class="text-center text-white">KEY</th>
						<th class="text-center text-white">SECRET</th>
						<th class="text-center text-white">HÀNH ĐỘNG</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$num = 1;
						$req = $db->Query("SELECT * FROM `tb_pusher` ORDER BY `id` DESC");
						while ($row = mysqli_fetch_array($req))
						{
					?>
					<tr>
						<td class="text-center"><?php echo $num; ?></td>
						<td class="text-center"><?php echo $row['pusher_app_id']; ?></td>
						<td class="text-center"><?php echo $row['pusher_cluster']; ?></td>
						<td class="text-center"><?php echo $row['pusher_key']; ?></td>
						<td class="text-center"><?php echo $row['pusher_secret']; ?></td>
						<td class="text-center">
                            <button class="btn btn-danger btn-sm py-2" href="#" onclick="RemoveAccount(<?php echo $row['id']; ?>)">
                            	<i class="fal fa-trash-alt" style="vertical-align: -2px; width: 1rem"></i>
                            </button>
                        </td>
					</tr>
					<?php
							$num++;
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<div class="modal fade" id="addPusherAccount" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Thêm tài khoản Pusher</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            	<div class="form-group">
            		<label for="app_id">Pusher App ID</label>
            		<input type="text" class="form-control" name="app_id" id="app_id" value="">
            	</div>
            	<div class="form-group">
            		<label for="cluster">Pusher Cluster</label>
            		<input type="text" class="form-control" name="cluster" id="cluster" value="">
            		<small id="otpHelp" class="form-text text-muted">Vui lòng chọn ap1 (Asia Pacific (Singapore))!</small>
            	</div>
            	<div class="form-group">
            		<label for="key">Pusher Key</label>
            		<input type="text" class="form-control" name="key" id="key" value="">
            	</div>
            	<div class="form-group">
            		<label for="secret">Pusher Secret</label>
            		<input type="text" class="form-control" name="secret" id="secret" value="">
            	</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-block" onclick="AddPusherEvent()">Thêm</button>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
	.dataTables_wrapper .dataTables_info,
	.dataTables_wrapper .dataTables_paginate {
		margin-top: 10px !important;
	}

	div.dataTables_wrapper div.dataTables_paginate ul.pagination {
		justify-content: center !important;
	}

</style>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/underscore@1.13.6/underscore-umd-min.js"></script>
<script type="text/javascript">
	$(document).ready(function (e){
		var datatable = $('#PusherAccountTable').DataTable({
			ordering: false,
			lengthChange: false,
			dom: 'rtp',
			searching: true,
			responsive: false,
			pageLength: 25,
			language: {
				info: "Hiển thị _START_-_END_ của _TOTAL_ kết quả.",
				infoEmpty: "Không có dữ liệu hiển thị!",
				zeroRecords: '<div class="text-center" style="margin-top: 10px"><img src="../assets/images/photos/404.png"><p class="font-weight-bold">Không tìm thấy dữ liệu...</p></div>'
			}
		});
	});
	function AddPusherEvent(data)
	{
		$.ajax({
			url: 'admin/api/pusher.php?act=create',
			type: 'POST',
			dataType: 'json',
			data: {
				app_id : $("#app_id").val(),
				cluster : $("#cluster").val(),
				key : $("#key").val(),
				secret : $("#secret").val()
			},
			success: function(response)
			{
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
				if (response.status == true) {
					$('.modal-backdrop').remove();
					loadFileFormUrl("admin/pusher");
				}
			}
		});
	}
	function RemoveAccount(data)
	{
		Swal.fire({
            title: 'Thông báo',
            text: "Bạn muốn xóa tài khoản này?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#BF3238',
            confirmButtonText: 'Xoá ngay',
        }).then((result) => {
            if (result.isConfirmed) {
				$.ajax({
					url: 'admin/api/pusher.php?act=delete',
					type: 'POST',
					dataType: 'json',
					data: {
						id : data
					},
					success: function(response)
					{
						SwalAlert(
							response.message,
							response.status == true ? "success" : "error"
						);
						if (response.status == true) {
							$('.modal-backdrop').remove();
							loadFileFormUrl("admin/pusher");
						}
					}
				});
			}
        });
	}
	function Search()
	{
		var search_data = $("#search_data").val();
		$('#PusherAccountTable').DataTable().search(search_data, false, false).draw();
	}

	function ResetDataTable()
	{
		$("#search_data").val("")
		$('#PusherAccountTable').DataTable().search("").draw(); 
	}
</script>