<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
?>

<div class="card">
	<div class="card-header d-flex justify-content-between align-items-center" style="font-size: 18px">
		Danh Sách Đen
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-md-2">
				<div class="form-group">
            		<label for="phone">Số điện thoại</label>
            		<input type="text" class="form-control" name="phone" id="phone" value="">
            	</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
            		<label for="phone">Từ ngày</label>
            		<input type="text" class="form-control" name="phone" id="phone" value="">
            	</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
            		<label for="phone">Đến ngày</label>
            		<input type="text" class="form-control" name="phone" id="phone" value="">
            	</div>
			</div>
			<div class="col-md-2">
				<div class="form-group">
            		<label for="phone">Đến ngày</label>
            		<input type="text" class="form-control" name="phone" id="phone" value="">
            	</div>
			</div>
			<div class="col-md-2">
				<button type="button" class="btn btn-primary" style="margin-top: 29px">
					<i class="fas fa-search" style="vertical-align: -2px;"></i>
				</button>
				<button type="button" class="btn" style="margin-top: 29px">
					<i class="fas fa-times-circle" style="vertical-align: -2px; color: red"></i>
				</button>
			</div>
		</div>
		<div class="table-responsive mb-3">
			<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center" id="BlackListTable">
				<thead>
					<tr class="badge-primary text-white">
						<th class="text-center text-white">SỐ ĐIỆN THOẠI</th>
						<th class="text-center text-white">TỔNG CƯỢC</th>
						<th class="text-center text-white">TỔNG THẮNG</th>
						<th class="text-center text-white">LỢI NHUẬN</th>
					</tr>
				</thead>
				<tbody>

				</tbody>

			</table>
		</div>
	</div>
</div>
<style type="text/css">
	.dataTables_wrapper .dataTables_info,
	.dataTables_wrapper .dataTables_paginate {
		margin-top: 10px !important;
	}

	div.dataTables_wrapper div.dataTables_paginate ul.pagination {
		justify-content: center !important;
	}

</style>
<script type="text/javascript">
	$(document).ready(function (e){
		var datatable = $('#BlackListTable').DataTable({
			ordering: false,
			lengthChange: false,
			dom: 'rtp',
			searching: true,
			responsive: false,
			pageLength: 25,
			language: {
				info: "Hiển thị _START_-_END_ của _TOTAL_ kết quả.",
				infoEmpty: "Không có dữ liệu hiển thị!",
				zeroRecords: '<div class="text-center" style="margin-top: 10px"><img src="../assets/images/photos/404.png"><p class="font-weight-bold">Không tìm thấy dữ liệu...</p></div>'
			}
		});
	});
</script>