<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
?>

<div class="card">
	<div class="card-header d-flex justify-content-between align-items-center" style="font-size: 18px">
		Danh Sách Thực Thi
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-md-10">
				<div class="form-group">
            		<input type="text" class="form-control" name="search_data" id="search_data" value="" placeholder="Nhập nội dung tìm kiếm">
            	</div>
			</div>
			<div class="col-md-2">
				<button type="button" class="btn btn-primary" onclick="Search()">
					<i class="fas fa-search" style="vertical-align: -2px;"></i>
				</button>
				<button type="button" class="btn" onclick="ResetDataTable()">
					<i class="fas fa-times-circle" style="vertical-align: -2px; color: red"></i>
				</button>
			</div>
		</div>
		<div class="table-responsive mb-3">
			<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center" id="AdminAccountTable">
				<thead>
					<tr class="badge-primary text-white">
						<th class="text-center text-white px-5">ID</th>
						<th class="text-center text-white">HÀNH ĐỘNG</th>
						<th class="text-center text-white">NỘI DUNG</th>
						<th class="text-center text-white">THỜI GIAN</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$req = $db->Query("SELECT * FROM `tb_logs` ORDER BY `id` DESC");
						while ($row = mysqli_fetch_array($req))
						{
					?>
					<tr>
						<td class="text-center"><?php echo $row['id']; ?></td>
						<td class="text-center"><span class="badge badge-success"><?php echo $row['action']; ?></span></td>
						<td class="text-center pe-2" style="max-width: 380px; overflow-x: hidden; text-overflow: ellipsis;"><?php echo $core->formatExportDatabase($row['content']); ?></td>
						<td class="text-center"><?php echo date("d-m-Y H:i:s", $row['created_at']); ?></td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<style type="text/css">
	.dataTables_wrapper .dataTables_info,
	.dataTables_wrapper .dataTables_paginate {
		margin-top: 10px !important;
	}

	div.dataTables_wrapper div.dataTables_paginate ul.pagination {
		justify-content: center !important;
	}

</style>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/underscore@1.13.6/underscore-umd-min.js"></script>
<script type="text/javascript">
	$(document).ready(function (e){
		var datatable = $('#AdminAccountTable').DataTable({
			ordering: false,
			lengthChange: false,
			dom: 'rtp',
			searching: true,
			responsive: false,
			pageLength: 25,
			language: {
				info: "Hiển thị _START_-_END_ của _TOTAL_ kết quả.",
				infoEmpty: "Không có dữ liệu hiển thị!",
				zeroRecords: '<div class="text-center" style="margin-top: 10px"><img src="../assets/images/photos/404.png"><p class="font-weight-bold">Không tìm thấy dữ liệu...</p></div>'
			}
		});
	});

	function Search()
	{
		var search_data = $("#search_data").val();
		$('#AdminAccountTable').DataTable().search(search_data, false, false).draw();
	}

	function ResetDataTable()
	{
		$("#search_data").val("")
		$('#AdminAccountTable').DataTable().search("").draw(); 
	}
</script>