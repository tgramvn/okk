<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
$total_amount = mysqli_fetch_assoc($db->Query("SELECT SUM(`balance`) FROM `tb_private_momo`"))['SUM(`balance`)'];
?>

<div class="card">
	<div class="card-header d-flex justify-content-between align-items-center" style="font-size: 18px">
		Quản Lý Tài Khoản MoMo
		<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addMomoAccount"><i class="fas fa-plus-circle" style="vertical-align: -2px;"></i></button>
	</div>
	<div class="card-body">
		<div class="d-flex justify-content-center align-items-center mb-3">
			<button type="button" class="btn btn-primary mx-auto">Tổng: <?php echo number_format($total_amount); ?>đ</button>
		</div>
		<div class="row">
			<div class="col-md-10">
				<div class="form-group">
            		<input type="text" class="form-control" name="search_data" id="search_data" value="" placeholder="Nhập nội dung tìm kiếm">
            	</div>
			</div>
			<div class="col-md-2">
				<button type="button" class="btn btn-primary" onclick="Search()">
					<i class="fas fa-search" style="vertical-align: -2px;"></i>
				</button>
				<button type="button" class="btn" onclick="ResetDataTable()">
					<i class="fas fa-times-circle" style="vertical-align: -2px; color: red"></i>
				</button>
			</div>
		</div>
		<div class="table-responsive mb-3">
			<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center" id="MomoAccountTable">
				<thead>
					<tr class="badge-primary text-white">
						<th class="text-center text-white px-5">ID</th>
						<th class="text-center text-white">SỐ ĐIỆN THOẠI</th>
						<th class="text-center text-white">TÊN TÀI KHOẢN</th>
						<th class="text-center text-white">SỐ DƯ</th>
						<th class="text-center text-white">SỐ LẦN</th>
						<th class="text-center text-white">CƯỢC MIN</th>
						<th class="text-center text-white">CƯỢC MAX</th>
						<th class="text-center text-white">GIỚI HẠN NGÀY</th>
						<th class="text-center text-white">GIỚI HẠN THÁNG</th>
						<th class="text-center text-white">ĐĂNH NHẬP</th>
						<th class="text-center text-white">CẬP NHẬT</th>
						<th class="text-center text-white">HÀNH ĐỘNG</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$i = 1;
						$req = $db->Query("SELECT * FROM `tb_private_momo`");
						while ($row = mysqli_fetch_array($req))
						{
							$req_momo = $db->Query("SELECT * FROM `tb_momo` WHERE `phone` = '".$row['phone']."'");
							while ($row_momo = mysqli_fetch_array($req_momo))
							{
					?>
					<tr>
						<td class="text-center"><?php echo $i; ?></td>
						<td class="text-center"><?php echo $row['phone']; ?></td>
						<td class="text-center"><?php echo mb_strtoupper($row['name']); ?></td>
						<td class="text-center"><?php echo number_format($row['balance']); ?> VND</td>

						<td class="text-center"><?php echo $row_momo['count']; ?>/<?php echo $row_momo['number']; ?></td>
						<td class="text-center"><?php echo number_format($row_momo['betMin']); ?>đ</td>
						<td class="text-center"><?php echo number_format($row_momo['betMax']); ?>đ</td>
						<td class="text-center"><?php echo number_format($row_momo['limitDay']); ?>đ</td>
						<td class="text-center"><?php echo number_format($row_momo['limitMonth']); ?>đ</td>

						<td class="text-center"><?php echo date("d-m-Y H:i:s", $row['updated_at']); ?></td>
						<td class="text-center"><?php echo date("d-m-Y H:i:s", $row_momo['cron_rand_time']); ?></td>

						<td class="text-center">
							<?php if ($row['is_invisible'] == 1) { ?>
							<button class="btn btn-info btn-sm mr-2 py-2" href="#" onclick="InVisibleMoMo(<?php echo $row['id']; ?>)">
								<i class="fal fa-eye" style="vertical-align: -2px; margin-left: -2px; width: 1.2rem"></i>
                            </button>
                            <?php } else { ?>
                            <button class="btn btn-dark btn-sm mr-2 py-2" href="#" onclick="VisibleMoMo(<?php echo $row['id']; ?>)">
								<i class="fal fa-eye-slash" style="vertical-align: -2px; margin-left: -2px; width: 1.2rem"></i>
                            </button>
                            <?php } ?>
                            <button class="btn btn-secondary btn-sm mr-2 py-2" href="#" onclick="ShowAccount(<?php echo $row_momo['id']; ?>)">
                            	<i class="fal fa-pen" style="vertical-align: -2px; width: 1rem"></i>
                            </button>
                            <button class="btn btn-danger btn-sm py-2" href="#" onclick="RemoveAccount(<?php echo $row['id']; ?>)">
                            	<i class="fal fa-trash-alt" style="vertical-align: -2px; width: 1rem"></i>
                            </button>
                        </td>
					</tr>
					<?php
							}
							$i++;
						}
					?>

				</tbody>
			</table>
		</div>
	</div>
</div>

<div class="modal fade" id="addMomoAccount" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Thêm tài khoản MOMO</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            	<div class="form-group">
            		<label for="phone">Số điện thoại</label>
            		<input type="text" class="form-control" name="phone" id="phone" value="">
            	</div>
            	<div class="form-group">
            		<label for="password">Mật khẩu</label>
            		<input type="text" class="form-control" name="password" id="password" value="">
            	</div>
            	<div class="form-group">
            		<label for="code">Mã OTP</label>
	            	<div class="input-group">
	            		<input type="text" class="form-control" name="code" id="code" aria-describedby="otpHelp" value="">
	            		<div class="input-group-append">
	            			<button class="btn btn-primary" type="button" onclick="OTPConnect();">Lấy Mã OTP</button>
	            		</div>
	            	</div>
	            	<small id="otpHelp" class="form-text text-muted">Nhập số điện thoại và mật khẩu rồi hãy lấy mã OTP!</small>
	            </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-block" onclick="AddMomoEvent()">Thêm</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="EditAccount" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cập nhật tài khoản</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            	<div class="form-group">
            		<label for="betMin">Cược Min</label>
            		<input type="text" class="form-control" name="betMin" id="betMin" value="">
            	</div>
            	<div class="form-group">
            		<label for="betMax">Cược Max</label>
            		<input type="text" class="form-control" name="betMax" id="betMax" value="">
            	</div>
            	<div class="form-group">
            		<label for="limitDay">Giới Hạn Ngày</label>
            		<input type="text" class="form-control" name="limitDay" id="limitDay" value="">
            	</div>
            	<div class="form-group">
            		<label for="limitMonth">Giới Hạn Tháng</label>
            		<input type="text" class="form-control" name="limitMonth" id="limitMonth" value="">
            	</div>
            </div>
            <div class="modal-footer">
            	<input type="hidden" name="u-id" id="u-id" value="">
                <button type="button" class="btn btn-primary btn-block" onclick="UpdateAccount()">Cập nhật</button>
            </div>
        </div>
    </div>
</div>

<style type="text/css">
	.dataTables_wrapper .dataTables_info,
	.dataTables_wrapper .dataTables_paginate {
		margin-top: 10px !important;
	}

	div.dataTables_wrapper div.dataTables_paginate ul.pagination {
		justify-content: center !important;
	}

</style>
<script type="text/javascript">
	$(document).ready(function (e){
		var datatable = $('#MomoAccountTable').DataTable({
			ordering: false,
			lengthChange: false,
			dom: 'rtp',
			searching: true,
			responsive: false,
			pageLength: 25,
			language: {
				info: "Hiển thị _START_-_END_ của _TOTAL_ kết quả.",
				infoEmpty: "Không có dữ liệu hiển thị!",
				zeroRecords: '<div class="text-center" style="margin-top: 10px"><img src="../assets/images/photos/404.png"><p class="font-weight-bold">Không tìm thấy dữ liệu...</p></div>'
			}
		});
	});

	function Search()
	{
		alert("asdas");
		var search_data = $("#search_data").val();
		$('#MomoAccountTable').DataTable().search(search_data, false, false).draw();
	}

	function ResetDataTable()
	{
		$("#search_data").val("")
		$('#MomoAccountTable').DataTable().search("").draw(); 
	}

	function OTPConnect()
	{
		$.ajax({
			url: 'admin/api/setup_momo.php?act=register',
			type: 'POST',
			dataType: 'json',
			data: {
				phone : $('#phone').val(),
				password : $('#password').val()
			},
			success: function(response)
			{
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
			}
		});
	}

	function AddMomoEvent()
	{
		$.ajax({
			url: 'admin/api/setup_momo.php?act=comfirm',
			type: 'POST',
			dataType: 'json',
			data: {
				phone : $('#phone').val(),
				code : $('#code').val()
			},
			success: function(response)
			{
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
				if (response.status == true) {
					$('.modal-backdrop').remove();
					loadFileFormUrl("admin/momo");
				}
			}
		});
	}

	function ShowAccount(data)
	{
		LoadAccount(data);
		$('#EditAccount').modal('show');
	}

	function VisibleMoMo(data_id) {
		$.ajax({
			url: 'admin/api/momo.php?act=show',
			type: 'POST',
			dataType: 'json',
			data: {
				id: data_id
			},
			beforeSend: function(){
			},
			success: function (response) {
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
				if (response.status == true) {
					$('.modal-backdrop').remove();
					loadFileFormUrl("admin/momo");
				}
			},
			error: function (error) {
				console.log(error);
			}
		});
	}

	function InVisibleMoMo(data_id) {
		$.ajax({
			url: 'admin/api/momo.php?act=hide',
			type: 'POST',
			dataType: 'json',
			data: {
				id: data_id
			},
			beforeSend: function(){
			},
			success: function (response) {
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
				if (response.status == true) {
					$('.modal-backdrop').remove();
					loadFileFormUrl("admin/momo");
				}
			},
			error: function (error) {
				console.log(error);
			}
		});
	}

	function LoadAccount(data)
	{
		$.ajax({
			url: 'admin/api/momo.php?act=load',
			type: 'POST',
			dataType: 'json',
			data: {
				id : data
			},
			success: function(response) {
				$("#u-id").val(response.id);
				$("#betMin").val(response.betMin);
				$("#betMax").val(response.betMax);
				$("#limitDay").val(response.limitDay);
				$("#limitMonth").val(response.limitMonth);
			}
		});
	}

	function UpdateAccount()
	{
		$.ajax({
			url: 'admin/api/momo.php?act=update',
			type: 'POST',
			dataType: 'json',
			data: {
				id : $("#u-id").val(),
				betMin : $("#betMin").val(),
				betMax : $("#betMax").val(),
				limitDay : $("#limitDay").val(),
				limitMonth : $("#limitMonth").val()
			},
			success: function(response)
			{
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
				if (response.status == true) {
					$('.modal-backdrop').remove();
					loadFileFormUrl("admin/momo");
				}
			}
		});
	}

	function RemoveAccount(data)
	{
		Swal.fire({
            title: 'Thông báo',
            text: "Bạn muốn xóa tài khoản này?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#BF3238',
            confirmButtonText: 'Xoá ngay',
        }).then((result) => {
            if (result.isConfirmed) {
				$.ajax({
					url: 'admin/api/momo.php?act=delete',
					type: 'POST',
					dataType: 'json',
					data: {
						id : data
					},
					success: function(response)
					{
						SwalAlert(
							response.message,
							response.status == true ? "success" : "error"
						);
						if (response.status == true) {
							$('.modal-backdrop').remove();
							loadFileFormUrl("admin/momo");
						}
					}
				});
			}
        });
	}

</script>