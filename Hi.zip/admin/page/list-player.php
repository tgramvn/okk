<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
?>

<div class="card">
	<div class="card-header d-flex justify-content-between align-items-center" style="font-size: 18px">
		Danh Sách Người Chơi
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-md-2">
				<div class="form-group">
            		<label for="phone">Số điện thoại</label>
            		<input type="text" class="form-control" name="phone" id="phone" value="" placeholder="Nhập số điện thoại">
            	</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
            		<label for="fromDate">Từ ngày</label>
            		<div class="input-group">
            			<input type="text" class="form-control" name="fromDate" id="fromDate" value="" placeholder="dd/mm/yyyy">
            			<div class="input-icon-addon">
            				<i class="fal fa-calendar text-dark"></i>
            			</div>
            		</div>
            	</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
            		<label for="toDate">Đến ngày</label>
            		<div class="input-group">
            		<input type="text" class="form-control" name="toDate" id="toDate" value="" placeholder="dd/mm/yyyy">
            			<div class="input-icon-addon">
            				<i class="fal fa-calendar text-dark"></i>
            			</div>
            		</div>
            	</div>
			</div>
			<div class="col-md-2">
				<div class="form-group">
            		<label for="curDate">Theo ngày</label>
            		<div class="input-group">
            		<input type="text" class="form-control" name="curDate" id="curDate" value="" placeholder="dd/mm/yyyy">
            			<div class="input-icon-addon">
            				<i class="fal fa-calendar text-dark"></i>
            			</div>
            		</div>
            	</div>
			</div>
			<div class="col-md-2">
				<button type="button" class="btn btn-primary" style="margin-top: 29px" onclick="Search()">
					<i class="fas fa-search" style="vertical-align: -2px;"></i>
				</button>
				<button type="button" class="btn" style="margin-top: 29px" onclick="ResetDataTable()">
					<i class="fas fa-times-circle" style="vertical-align: -2px; color: red"></i>
				</button>
			</div>
		</div>
		<div class="table-responsive mb-3">
			<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center" id="ListPlayerTable">
				<thead>
					<tr class="badge-primary text-white">
						<th class="text-center text-white">SỐ ĐIỆN THOẠI</th>
						<th class="text-center text-white">TỔNG CƯỢC</th>
						<th class="text-center text-white">TỔNG THẮNG</th>
						<th class="text-center text-white">LỢI NHUẬN</th>
						<th class="text-center text-white d-none">THỜI GIAN</th>
					</tr>
				</thead>
				<tbody>
				<?php
					$num = 0;
					$player_array = array();
					$req = $db->Query("SELECT DISTINCT `phone_player` FROM `tb_history` WHERE `is_bot` != '1'");
					while ($row_main = mysqli_fetch_array($req))
					{
						$reqs = $db->Query("SELECT * FROM `tb_history` WHERE `phone_player` = '".$row_main['phone_player']."'");
						while ($row = mysqli_fetch_array($reqs))
						{
							if (!in_array($row['phone_player'], array_column($player_array, 'phone_player')))
							{
								$player_array[] = array(
									'phone_player' => $row['phone_player'],
									'money' => $row['money'],
									'bonus' => $row['bonus'],
									'created_at' => $row['created_at']
								);
							}
							else
							{
								foreach ($player_array as $key => $value)
								{
									$player_array[$key]['money'] = $player_array[$key]['money'] + $row['money'];
									$player_array[$key]['bonus'] = $player_array[$key]['bonus'] + $row['bonus'];
								}
							}
						}
						$num++;
					}

					$price = array_column($player_array, 'money');
					array_multisort($price, SORT_DESC, $player_array);

					for ($i = 0; $i < count($player_array); $i++)
					{
						$total_amount = $player_array[$i]['money'] - $player_array[$i]['bonus'];
						$profit = ($total_amount > 0) ? '<span class="text-success">+'.number_format($total_amount).'đ</span>' : '<span class="text-success">'.number_format($total_amount).'đ</span>';

						echo '<tr>';
					    echo '<td class="text-center">'.$player_array[$i]['phone_player'].'</td>';
					    echo '<td class="text-center">'.number_format($player_array[$i]['money']).'đ</td>';
					    echo '<td class="text-center">'.number_format($player_array[$i]['bonus']).'đ</td>';
					    echo '<td class="text-center"><b>'.$profit.'</b></td>';
					    echo '<td class="text-center d-none">'.date("d-m-Y H:i:s", $player_array[$i]['created_at']).'</td>';
					    echo '</tr>';
					}
				?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<style type="text/css">
	.dataTables_wrapper .dataTables_info,
	.dataTables_wrapper .dataTables_paginate {
		margin-top: 10px !important;
	}

	div.dataTables_wrapper div.dataTables_paginate ul.pagination {
		justify-content: center !important;
	}

</style>
<script type="text/javascript">
	$(document).ready(function (e){
		var datatable = $('#ListPlayerTable').DataTable({
			ordering: false,
			lengthChange: false,
			dom: 'rtp',
			searching: true,
			responsive: false,
			pageLength: 40,
			language: {
				info: "Hiển thị _START_-_END_ của _TOTAL_ kết quả.",
				infoEmpty: "Không có dữ liệu hiển thị!",
				zeroRecords: '<div class="text-center" style="margin-top: 10px"><img src="../assets/images/photos/404.png"><p class="font-weight-bold">Không tìm thấy dữ liệu...</p></div>'
			}
		});
		$('#fromDate, #toDate, #curDate').flatpickr({
			dateFormat: "d-m-Y",
		});
	});
	function Search()
	{
		if ($('#phone').val() != "" && $('#fromDate').val() == "" && $('#toDate').val() == "" && $('#curDate').val() == "") {
			$.fn.dataTable.ext.search.push(
				function(settings, data, dataIndex) {
					var phoneNum = $('#phone').val();
					if (~data[0].toLowerCase().indexOf(phoneNum) && phoneNum != "") {
						return true;
					}
					return false;
				});
			$('#ListPlayerTable').DataTable().draw();
		}
		if ($('#phone').val() == "" && $('#fromDate').val() != "" && $('#toDate').val() != "" && $('#curDate').val() == "") {
			$.fn.dataTable.ext.search.push(
				function(settings, data, dataIndex) {
					var fromDate = $('#fromDate').val();
					var toDate = $('#toDate').val();

					const myDate = data[1].split(" ");
					const timeSplit = myDate[1].split("/");
					var createdAt = (timeSplit[2] + "-" + timeSplit[1] + "-" + timeSplit[0]) || 0;

					if ((fromDate == "" || toDate == "") || (moment(createdAt).isSameOrAfter(fromDate) && moment(createdAt).isSameOrBefore(toDate))) {
						return true;
					}

					return false;
				}
				);
			$('#ListPlayerTable').DataTable().draw();
		}
		if ($('#phone').val() == "" && $('#fromDate').val() == "" && $('#toDate').val() == "" && $('#curDate').val() != "") {
			$.fn.dataTable.ext.search.push(
				function(settings, data, dataIndex) {
					var curDate = $('#curDate').val();

					const myDate = data[1].split(" ");
					const timeSplit = myDate[1].split("/");
					var createdAt = (timeSplit[2] + "-" + timeSplit[1] + "-" + timeSplit[0]) || 0;

					if (createdAt == curDate) {
						return true;
					}

					return false;
				}
				);
			$('#ListPlayerTable').DataTable().draw();
		}
	}

	function ResetDataTable()
	{
		$("#search_data").val("")
		$("#fromDate").val("")
		$("#toDate").val("")
		$("#curDate").val("")
		$('#ListPlayerTable').DataTable().search("").draw(); 
	}
</script>