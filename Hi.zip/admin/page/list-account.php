<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
?>

<div class="card">
	<div class="card-header d-flex justify-content-between align-items-center" style="font-size: 18px">
		Danh Sách Tài Khoản
		<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#AddAccount"><i class="fas fa-plus-circle" style="vertical-align: -2px;"></i></button>
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-md-10">
				<div class="form-group">
            		<input type="text" class="form-control" name="search_data" id="search_data" value="" placeholder="Nhập nội dung tìm kiếm">
            	</div>
			</div>
			<div class="col-md-2">
				<button type="button" class="btn btn-primary" onclick="Search()">
					<i class="fas fa-search" style="vertical-align: -2px;"></i>
				</button>
				<button type="button" class="btn" onclick="ResetDataTable()">
					<i class="fas fa-times-circle" style="vertical-align: -2px; color: red"></i>
				</button>
			</div>
		</div>
		<div class="table-responsive mb-3">
			<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center" id="AdminAccountTable">
				<thead>
					<tr class="badge-primary text-white">
						<th class="text-center text-white">ID</th>
						<th class="text-center text-white">HỌ TÊN</th>
						<th class="text-center text-white">USERNAME</th>
						<th class="text-center text-white">IP</th>
						<th class="text-center text-white">ĐĂNG NHẬP CUỐI</th>
						<th class="text-center text-white">HÀNH ĐỘNG</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$req = $db->Query("SELECT * FROM `tb_users`");
						while ($row = mysqli_fetch_array($req))
						{
					?>
					<tr>
						<td class="text-center"><?php echo $row['id']; ?></td>
						<td class="text-center"><?php echo $core->formatExportDatabase($row['full_name']); ?></td>
						<td class="text-center"><span class="badge badge-info"><?php echo $row['username']; ?></span></td>
						<td class="text-center"><?php echo $row['ip_address']; ?></td>
						<td class="text-center"><?php echo date("d-m-Y H:i:s", $row['last_access']); ?></td>
						<td class="text-center">
                            <button class="btn btn-secondary btn-sm mr-2 py-2" href="#" onclick="ShowAccount(<?php echo $row['id']; ?>)">
                            	<i class="fal fa-pen" style="vertical-align: -2px; width: 1rem"></i>
                            </button>
                            <button class="btn btn-danger btn-sm py-2" href="#" onclick="RemoveAccount(<?php echo $row['id']; ?>)">
                            	<i class="fal fa-trash-alt" style="vertical-align: -2px; width: 1rem"></i>
                            </button>
                        </td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<div class="modal fade" id="AddAccount" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Thêm tài khoản</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            	<div class="form-group">
            		<label for="phone">Họ và tên</label>
            		<input type="text" class="form-control" name="fullname" id="fullname" value="">
            	</div>
            	<div class="form-group">
            		<label for="username">Username</label>
            		<input type="text" class="form-control" name="username" id="username" value="">
            	</div>
            	<div class="form-group">
            		<label for="password">Mật khẩu</label>
            		<input type="text" class="form-control" name="password" id="password" value="">
            	</div>
            	<div class="form-group">
            		<label for="password">Nhập lại mật khẩu</label>
            		<input type="text" class="form-control" name="repassword" id="repassword" value="">
            	</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-block" onclick="CreateAccount()">Thêm</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="EditAccount" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chỉnh sửa tài khoản</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            	<div class="form-group">
            		<label for="u-fullname">Họ và tên</label>
            		<input type="text" class="form-control" name="u-fullname" id="u-fullname" value="">
            	</div>
            	<div class="form-group">
            		<label for="u-username">Username</label>
            		<input type="text" class="form-control" name="u-username" id="u-username" value="">
            	</div>
            	<div class="form-group">
            		<label for="u-password">Mật khẩu mới</label>
            		<input type="text" class="form-control" name="u-password" id="u-password" value="">
            		<small id="otpHelp" class="form-text text-muted">Bỏ trống khi không cập nhật mật khẩu!</small>
            	</div>
            </div>
            <div class="modal-footer">
            	<input type="hidden" name="u-id" id="u-id" value="">
                <button type="button" class="btn btn-primary btn-block" onclick="UpdateAccount()">Cập nhật</button>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
	.dataTables_wrapper .dataTables_info,
	.dataTables_wrapper .dataTables_paginate {
		margin-top: 10px !important;
	}

	div.dataTables_wrapper div.dataTables_paginate ul.pagination {
		justify-content: center !important;
	}

</style>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/underscore@1.13.6/underscore-umd-min.js"></script>
<script type="text/javascript">
	$(document).ready(function (e){
		var datatable = $('#AdminAccountTable').DataTable({
			ordering: false,
			lengthChange: false,
			dom: 'rtp',
			searching: true,
			responsive: false,
			pageLength: 25,
			language: {
				info: "Hiển thị _START_-_END_ của _TOTAL_ kết quả.",
				infoEmpty: "Không có dữ liệu hiển thị!",
				zeroRecords: '<div class="text-center" style="margin-top: 10px"><img src="../assets/images/photos/404.png"><p class="font-weight-bold">Không tìm thấy dữ liệu...</p></div>'
			}
		});
	});

	function Search()
	{
		var search_data = $("#search_data").val();
		$('#AdminAccountTable').DataTable().search(search_data, false, false).draw();
	}

	function ResetDataTable()
	{
		$("#search_data").val("")
		$('#AdminAccountTable').DataTable().search("").draw(); 
	}

	function CreateAccount(data)
	{
		$.ajax({
			url: 'admin/api/account.php?act=create',
			type: 'POST',
			dataType: 'json',
			data: {
				fullname : $("#fullname").val(),
				username : $("#username").val(),
				password : $("#password").val(),
				repassword : $("#repassword").val()
			},
			success: function(response)
			{
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
				if (response.status == true) {
					$('.modal-backdrop').remove();
					loadFileFormUrl("admin/list-account");
				}
			}
		});
	}

	function ShowAccount(data)
	{
		LoadAccount(data);
		$('#EditAccount').modal('show');
	}

	function LoadAccount(data)
	{
		$.ajax({
			url: 'admin/api/account.php?act=load',
			type: 'POST',
			dataType: 'json',
			data: {
				id : data
			},
			success: function(response) {
				$("#u-id").val(response.id);
				$("#u-fullname").val(decodeEntities(response.full_name));
				$("#u-username").val(response.mail);
			}
		});
	}

	function UpdateAccount()
	{
		$.ajax({
			url: 'admin/api/account.php?act=update',
			type: 'POST',
			dataType: 'json',
			data: {
				id : $("#u-id").val(),
				fullname : $("#u-fullname").val(),
				username : $("#u-username").val(),
				password : $("#u-password").val(),
			},
			success: function(response)
			{
				SwalAlert(
					response.message,
					response.status == true ? "success" : "error"
				);
				if (response.status == true) {
					$('.modal-backdrop').remove();
					loadFileFormUrl("admin/list-account");
				}
			}
		});
	}

	function RemoveAccount(data)
	{
		Swal.fire({
            title: 'Thông báo',
            text: "Bạn muốn xóa tài khoản này?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#BF3238',
            confirmButtonText: 'Xoá ngay',
        }).then((result) => {
            if (result.isConfirmed) {
				$.ajax({
					url: 'admin/api/account.php?act=delete',
					type: 'POST',
					dataType: 'json',
					data: {
						id : data
					},
					success: function(response)
					{
						SwalAlert(
							response.message,
							response.status == true ? "success" : "error"
						);
						if (response.status == true) {
							$('.modal-backdrop').remove();
							loadFileFormUrl("admin/list-account");
						}
					}
				});
			}
        });
	}

	function decodeEntities(encodedString)
	{
		var textArea = document.createElement('textarea');
		textArea.innerHTML = encodedString;
		return textArea.value;
	}
</script>