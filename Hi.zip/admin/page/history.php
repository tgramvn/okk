<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
?>

<div class="card">
	<div class="card-header" style="font-size: 18px">
		Lịch Sử Giao Dịch
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-md-10">
				<div class="form-group">
            		<input type="text" class="form-control" name="phone" id="phone" value="" placeholder="Nhập nội dung tìm kiếm">
            	</div>
			</div>
			<div class="col-md-2">
				<button type="button" class="btn btn-primary">
					<i class="fas fa-search" style="vertical-align: -2px;"></i>
				</button>
				<button type="button" class="btn">
					<i class="fas fa-times-circle" style="vertical-align: -2px; color: red"></i>
				</button>
			</div>
		</div>
		<div class="table-responsive mb-3">
			<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center" id="HisoryTable">
				<thead>
					<tr class="badge-primary text-white">
						<th class="text-center text-white px-5">ID</th>
						<th class="text-center text-white">MÃ GIAO DỊCH</th>
						<th class="text-center text-white">SỐ MOMO NHẬN</th>
						<th class="text-center text-white">SỐ ĐIỆN THOẠI</th>
						<th class="text-center text-white">TRÒ CHƠI</th>
						<th class="text-center text-white">NỘI DUNG</th>
						<th class="text-center text-white">TIỀN NHẬN</th>
						<th class="text-center text-white">THANH TOÁN</th>
						<th class="text-center text-white">THỜI GIAN</th>
						<th class="text-center text-white">TRẠNG THÁI</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$i = 1;
					$req = $db->Query("SELECT * FROM `tb_history` WHERE `is_bot` != '1' ORDER BY `id` DESC");
					while ($row = mysqli_fetch_array($req))
					{
						if ($row['money'] > 100)
						{
							if ($row['gameId'] != 0)
							{
								$game = $db->Fetch_Array("SELECT * FROM `tb_game` WHERE `id` = '".$row['gameId']."'");
							}
							else
							{
								$game['gameName'] = "Không có";
							}

							if ($row['pay_at'] == "" && $row['stated_at'] == "lose")
							{
								$pay_stat = '<span class="px-2 py-1 bg-danger rounded text-white mr-1" >Thua</span>';
							}
							else if ($row['pay_at'] == 'wait')
							{
								$pay_stat = '<span class="px-2 py-1 bg-warning rounded text-white mr-1">Chờ chuyển</span>';
							}
							else if ($row['pay_at'] == 'errorComment')
							{
								$pay_stat = '<span class="px-2 py-1 bg-danger rounded text-white mr-1">Sai cú pháp</span>';
							}
							else if ($row['pay_at'] == 'done' && $row['stated_at'] == "lose")
							{
								$pay_stat = '<span class="px-2 py-1 bg-danger rounded text-white mr-1">Thua</span>';
							}
							else if ($row['pay_at'] == 'done' && $row['stated_at'] == "win")
							{
								$pay_stat = '<span class="px-2 py-1 bg-success rounded text-white mr-1">Đã chuyển</span>';
							}
							$stat = ($row['stated_at'] == 'win') ? '<span class="px-2 py-1 bg-success rounded text-white mr-1">Thắng</span>' : '<span class="px-2 py-1 bg-primary rounded text-white mr-1">Thua</span>';

							$content = empty($row['content']) ? '<b>Lỗi nội dung</b>' : '<b>'.$row['content'].'</b>';
					?>
						<tr>
							<td class="text-center"><?php echo $i; ?></td>
							<td class="text-center"><?php echo $row['momo_txn']; ?></td>
							<td class="text-center"><?php echo $row['phone_recv']; ?></td>
							<td class="text-center"><?php echo $row['phone_player']; ?></td>
							<td class="text-center"><span class="px-2 py-1 bg-info rounded text-white mr-1"><?php echo $game['gameName']; ?></span></td>
							<td class="text-center"><?php echo $content; ?></td>
							<td class="text-center"><?php echo number_format($row['money']); ?> VND</td>
							<td class="text-center"><?php echo $pay_stat; ?></td>
							<td class="text-center"><?php echo date("d-m-Y H:i:s", $row['created_at']); ?></td>
							<td class="text-center"><?php echo $stat; ?></td>
						</tr>
					<?php
						}
						$i++;
					}
					?>

				</tbody>
			</table>

		</div>
	</div>
</div>
<style type="text/css">
	.dataTables_wrapper .dataTables_info,
	.dataTables_wrapper .dataTables_paginate {
		margin-top: 10px !important;
	}

	div.dataTables_wrapper div.dataTables_paginate ul.pagination {
		justify-content: center !important;
	}

</style>
<script type="text/javascript">
	$(document).ready(function (e){
		var datatable = $('#HisoryTable').DataTable({
			ordering: false,
			lengthChange: false,
			dom: 'rtp',
			searching: true,
			responsive: false,
			pageLength: 25,
			language: {
				info: "Hiển thị _START_-_END_ của _TOTAL_ kết quả.",
				infoEmpty: "Không có dữ liệu hiển thị!",
				zeroRecords: '<div class="text-center" style="margin-top: 10px"><img src="../assets/images/photos/404.png"><p class="font-weight-bold">Không tìm thấy dữ liệu...</p></div>'
			}
		});
	});
</script>