<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

$take_amount_day = 0;
$receiver_amount_day = 0;

$take_amount_month = 0;
$receiver_amount_month = 0;

$win_day = 0;
$lose_day = 0;
$error_day = 0;
$refund_day = 0;

$win_month = 0;
$lose_month = 0;
$error_month = 0;
$refund_month = 0;

$history = $db->Query("SELECT * FROM `tb_history` WHERE `is_bot` = '0'");
$momo_history = $db->Query("SELECT * FROM `tb_momo_transfer_history`");

while ($row = mysqli_fetch_array($history))
{
	if (date("d-m-Y", $row['created_at']) == date("d-m-Y", time()))
	{
		if ($row['stated_at'] == 'win')
		{
			$win_day = $win_day + 1;
		}
		if ($row['stated_at'] == 'lose' && $row['pay_at'] == 'done')
		{
			$lose_day = $lose_day + 1;
		}
		if ($row['pay_at'] == 'errorComment' && $row['stated_at'] == 'lose' || $row['pay_at'] == 'limitBet' && $row['stated_at'] == 'lose')
		{
			$error_day = $error_day + 1;
		}
		if ($row['pay_at'] == 'refund')
		{
			$refund_day = $refund_day + 1;
		}
	}
	if (date("m-Y", $row['created_at']) == date("m-Y", time()))
	{
		if ($row['stated_at'] == 'win')
		{
			$win_month = $win_month + '1';
		}
		if ($row['stated_at'] == 'lose' && $row['pay_at'] == 'done')
		{
			$lose_month = $lose_month + 1;
		}
		if ($row['pay_at'] == 'errorComment' && $row['stated_at'] == 'lose' || $row['pay_at'] == 'limitBet' && $row['stated_at'] == 'lose')
		{
			$error_month = $error_month + 1;
		}
		if ($row['pay_at'] == 'refund')
		{
			$refund_month = $refund_month + 1;
		}
	}

	if (date("d-m-Y", $row['created_at']) == date("d-m-Y", time()))
	{
		$take_amount_day = $take_amount_day + $row['money'];
	}
	if (date("m-Y", $row['created_at']) == date("m-Y", time()))
	{
		$take_amount_month = $take_amount_month + $row['money'];
	}
}
while ($row = mysqli_fetch_array($momo_history))
{
	if (date("d-m-Y", $row['created_at']) == date("d-m-Y", time()))
	{
		$receiver_amount_day = $receiver_amount_day + $row['amount'];
	}
	if (date("m-Y", $row['created_at']) == date("m-Y", time()))
	{
		$receiver_amount_month = $receiver_amount_month + $row['amount'];
	}
}

$profit_amount_day = $take_amount_day - $receiver_amount_day;
$profit_amount_month = $take_amount_month - $receiver_amount_month;
?>


<div class="text-center text-white h3 mb-5">
	Ngày <?php echo date("d/m/Y", time()); ?> <i class="fas fa-calendar-alt"></i>
</div>
<div class="row">
	<div class="col-md-4 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-primary">
						<div class="box-background">
							<i class="fal fa-dollar-sign fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo number_format($take_amount_day); ?> đ</div>
					<div class="font-weight-normal">Tổng nhận</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-4 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-secondary">
						<div class="box-background">
							<i class="fal fa-satellite-dish fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo number_format($receiver_amount_day); ?> đ</div>
					<div class="font-weight-normal">Tổng chi</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-4 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-info">
						<div class="box-background">
							<i class="fal fa-heart-rate fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo number_format($profit_amount_day); ?> đ</div>
					<div class="font-weight-normal">Doanh thu</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-3 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-info">
						<div class="box-background">
							<i class="fal fa-badge-check fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo $win_day; ?></div>
					<div class="font-weight-normal">Tổng thắng</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-3 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-dark">
						<div class="box-background">
							<i class="fal fa-times-square fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo $lose_day; ?></div>
					<div class="font-weight-normal">Tổng thua</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-3 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-danger">
						<div class="box-background">
							<i class="fal fa-exclamation-triangle fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo $error_day; ?></div>
					<div class="font-weight-normal">Tổng lỗi</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-3 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-warning">
						<div class="box-background">
							<i class="fal fa-redo-alt fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo $refund_day; ?></div>
					<div class="font-weight-normal">Tổng hoàn tiền</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="text-center text-white h3 mt-5 mb-5">
	Tháng <?php echo date("m/Y", time()); ?> <i class="fas fa-calendar-alt"></i>
</div>

<div class="row">
	<div class="col-md-4 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-primary">
						<div class="box-background">
							<i class="fal fa-dollar-sign fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo number_format($take_amount_month); ?> đ</div>
					<div class="font-weight-normal">Tổng nhận</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-4 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-secondary">
						<div class="box-background">
							<i class="fal fa-satellite-dish fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo number_format($receiver_amount_month); ?> đ</div>
					<div class="font-weight-normal">Tổng chi</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-4 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-info">
						<div class="box-background">
							<i class="fal fa-heart-rate fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo number_format($profit_amount_month); ?> đ</div>
					<div class="font-weight-normal">Doanh thu</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-3 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-info">
						<div class="box-background">
							<i class="fal fa-badge-check fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo $win_month; ?></div>
					<div class="font-weight-normal">Tổng thắng</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-3 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-dark">
						<div class="box-background">
							<i class="fal fa-times-square fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo $lose_month; ?></div>
					<div class="font-weight-normal">Tổng thua</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-3 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-danger">
						<div class="box-background">
							<i class="fal fa-exclamation-triangle fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo $error_month; ?></div>
					<div class="font-weight-normal">Tổng lỗi</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-3 mb-5">
		<div class="box rounded">
			<div class="row align-items-center">
				<div class="col-3 text-center">
					<div class="box-icon bg-warning">
						<div class="box-background">
							<i class="fal fa-redo-alt fa-2x"></i>
						</div>
					</div>
				</div>
				<div class="col-9">
					<div class="cash"><?php echo $refund_month; ?></div>
					<div class="font-weight-normal">Tổng hoàn tiền</div>
				</div>
			</div>
		</div>
	</div>
</div>


<div class="card mt-5">
	<div class="card-header d-flex justify-content-between align-items-center" style="font-size: 18px">
		Thống Kê Tháng <?php echo date("m-Y", time()); ?>
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-10">
				<div class="form-group">
            		<input type="text" class="form-control" name="search_data" id="search_data" value="" placeholder="Nhập nội dung tìm kiếm">
            	</div>
			</div>
			<div class="col-2">
				<button type="button" class="btn btn-primary" onclick="Search()">
					<i class="fas fa-search" style="vertical-align: -2px;"></i>
				</button>
				<button type="button" class="btn" onclick="ResetDataTable()">
					<i class="fas fa-times-circle" style="vertical-align: -2px; color: red"></i>
				</button>
			</div>
		</div>

		<div class="row">
			<div class="col-12">
				<div class="table-responsive mb-5">
					<table class="table card-table table-vcenter text-nowrap table-bordered table-striped text-center" id="MainHistoryTable">
						<thead>
							<tr class="badge-primary text-white">
								<th class="text-center text-white px-5">ID</th>
								<th class="text-center text-white">MÃ GIAO DỊCH</th>
								<th class="text-center text-white">SỐ MOMO NHẬN</th>
								<th class="text-center text-white">SỐ ĐIỆN THOẠI</th>
								<th class="text-center text-white">TRÒ CHƠI</th>
								<th class="text-center text-white">NỘI DUNG</th>
								<th class="text-center text-white">TIỀN NHẬN</th>
								<th class="text-center text-white">THANH TOÁN</th>
								<th class="text-center text-white">THỜI GIAN</th>
								<th class="text-center text-white">TRẠNG THÁI</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$i = 1;
							$req = $db->Query("SELECT * FROM `tb_history` WHERE `is_bot` != '1' ORDER BY `id` DESC");
							while ($row = mysqli_fetch_array($req))
							{
								if ($row['money'] > 100)
								{
									if ($row['gameId'] != 0)
									{
										$game = $db->Fetch_Array("SELECT * FROM `tb_game` WHERE `id` = '".$row['gameId']."'");
									}
									else
									{
										$game['gameName'] = "Không có";
									}

									if ($row['pay_at'] == "" && $row['stated_at'] == "lose")
									{
										$pay_stat = '<span class="px-2 py-1 bg-danger rounded text-white mr-1" >Lỗi giao dịch</span>';
									}
									else if ($row['pay_at'] == 'wait')
									{
										$pay_stat = '<span class="px-2 py-1 bg-warning rounded text-white mr-1">Chờ chuyển</span>';
									}
									else if ($row['pay_at'] == 'errorComment')
									{
										$pay_stat = '<span class="px-2 py-1 bg-danger rounded text-white mr-1">Sai cú pháp</span>';
									}
									else if ($row['pay_at'] == 'done' && $row['stated_at'] == "lose")
									{
										$pay_stat = '<span class="px-2 py-1 bg-danger rounded text-white mr-1">Thua</span>';
									}
									else if ($row['pay_at'] == 'done' && $row['stated_at'] == "win")
									{
										$pay_stat = '<span class="px-2 py-1 bg-success rounded text-white mr-1">Đã chuyển</span>';
									}
									$stat = ($row['stated_at'] == 'win') ? '<span class="px-2 py-1 bg-success rounded text-white mr-1">Thắng</span>' : '<span class="px-2 py-1 bg-primary rounded text-white mr-1">Thua</span>';

									$content = empty($row['content']) ? '<b>Lỗi nội dung</b>' : '<b>'.$row['content'].'</b>';
								?>
								<tr>
									<td class="text-center"><?php echo $i; ?></td>
									<td class="text-center"><?php echo $row['momo_txn']; ?></td>
									<td class="text-center"><?php echo $row['phone_recv']; ?></td>
									<td class="text-center"><?php echo $row['phone_player']; ?></td>
									<td class="text-center"><span class="px-2 py-1 bg-info rounded text-white mr-1"><?php echo $game['gameName']; ?></span></td>
									<td class="text-center"><?php echo $content; ?></td>
									<td class="text-center"><?php echo number_format($row['money']); ?> VND</td>
									<td class="text-center"><?php echo $pay_stat; ?></td>
									<td class="text-center"><?php echo date("d-m-Y H:i:s", $row['created_at']); ?></td>
									<td class="text-center"><?php echo $stat; ?></td>
								</tr>
								<?php
									}
									$i++;
								}
								?>

						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function (e){
		var datatable = $('#MainHistoryTable').DataTable({
			ordering: false,
			lengthChange: false,
			dom: 'rtp',
			searching: true,
			responsive: false,
			pageLength: 40,
			language: {
				info: "Hiển thị _START_-_END_ của _TOTAL_ kết quả.",
				infoEmpty: "Không có dữ liệu hiển thị!",
				zeroRecords: '<div class="text-center" style="margin-top: 10px"><img src="../assets/images/photos/404.png"><p class="font-weight-bold">Không tìm thấy dữ liệu...</p></div>'
			}
		});
	});
	function Search()
	{
		var search_data = $("#search_data").val();
		$('#MainHistoryTable').DataTable().search(search_data, false, false).draw();
	}

	function ResetDataTable()
	{
		$("#search_data").val("")
		$('#MainHistoryTable').DataTable().search("").draw(); 
	}

</script>
<style type="text/css">
	.page-main:after {
	    height: 100%;
	    background-image: url(../../assets/images/bg-01.jpg);
	    position: absolute;
	    background-size: cover;
	    z-index: -1;
	    width: 100%;
	    top: 0;
	}
	.dataTables_wrapper .dataTables_info,
	.dataTables_wrapper .dataTables_paginate {
		margin-top: 10px !important;
	}

	div.dataTables_wrapper div.dataTables_paginate ul.pagination {
		justify-content: center !important;
	}
	.box {
		background-color: #fff;
		padding: 10px 12px;
		border-radius: 6px!important;
		box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
	}
	.box-icon {
		width: 55px;
		height: 55px;
		color: #fff;
		border-radius: 8px;
	}
	.box-background {
		width: 100%;
		height: 100%;
		background-image: url('../../assets/images/circle.svg');
		background-repeat: no-repeat;
    	background-position-x: 16px;
    	background-size: cover;
		display: flex;
		justify-content: center;
		align-items: center;
		padding: 8px;
	}
	.cash {
		font-weight: bold;
		font-size: 24px;
	}
</style>