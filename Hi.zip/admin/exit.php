<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../incfiles/init.php');

if ($account)
{
	if(isset($_SESSION['user_id']) && isset($_SESSION['user_password'])) 
	{
		unset($_SESSION['user_id']);
		unset($_SESSION['user_password']);
		header('Location: /admin/login');
		exit();
	}
}
else
{
	die($core->ajaxReturnMsg(false, ""));
}

ob_flush();
?>