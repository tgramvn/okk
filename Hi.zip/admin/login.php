<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../incfiles/init.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <base href="<?php echo $core->formatExportDatabase($core->isHomeSetting('website_url')); ?>">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="robots" content="noindex, nofollow" />
    <title>Đăng Nhập Quản Trị</title>
    <link rel="shortcut icon" href="../assets/images/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="../assets/css/app.css">
    <link href="../assets/plugins/notify/css/jquery.growl.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/richtext.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../assets/js/vendors/jquery-3.2.1.min.js"></script>
</head>

<body class="login-img">
    <div id="global-loader" style="display: none;"></div>
    <div class="page h-100">
        <div class="page-content">
            <div class="container">
                <div class="row mx-0 justify-content-center">
                    <div class="login rounded col-md-5">

                        <form action="#" method="POST" class="mb-5">
                            <div class="p-5 text-center">
                                <h2 class="fw-bold mb-2 text-uppercase">ĐĂNG NHẬP</h2>
                                <p class="mb-3">Vui lòng nhập tài khoản và mật khẩu!</p>
                            </div>
                            <div class="form-outline mb-4">
                                <label for="username">Username</label>
                                <div class="input-icon form-group wrap-input">
                                    <span class="input-icon-addon search-icon"> <i class="far fa-envelope fa-lg text-primary"></i></span>
                                    <input type="text" class="form-control form-control-lg" name="username" id="username" value="" placeholder="Username">
                                </div>
                            </div>
                            <div class="form-outline mb-5">
                                <label for="password">Password</label>
                                <div class="input-icon form-group wrap-input">
                                    <span class="input-icon-addon search-icon"> <i class="far fa-lock-alt fa-lg text-primary"></i></span>
                                    <input type="password" class="form-control form-control-lg" name="password" id="password" value="" placeholder="Password">
                                </div>
                            </div>
                            <button type="button" id="btnLogin" onclick="isLogin(this);" class="btn btn-primary btn-lg btn-block">Đăng Nhập</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        function isLogin(data)
        {
            $.ajax({
                url: 'admin/api/login.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    username : $('#username').val(),
                    password : $('#password').val()
                },
                success: function(response)
                {
                    var icon = response.status == true ? "success" : "error";
                    Swal.fire({
                        icon,
                        title: "Thông báo",
                        html: response.message,
                        confirmButtonColor: '#3085d6',
                        heightAuto: false
                    });
                    if (response.status == true) {
                        setTimeout(() => {
                            window.location.href = "/admin";
                        }, 2000);
                    }
                }
            });
        }
    </script>
    <style type="text/css">
        .login {
            background-color: #fff;
            padding: 50px;
            box-shadow: rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px;
        }
        .fw-bold {
            font-weight: bold;
        }
        .swal2-container {
            z-index: 100001 !important;
        }
        .swal2-popup {
            font-family: 'Nunito', sans-serif!important;
            padding-bottom: 10px!important;
            border-radius: 18px!important;
            box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
        }
        .swal2-actions {
            margin: 15px 0 0!important;
            padding-top: 10px!important;
            border-top: 1px solid #eee;
        }
        .swal2-title {
            margin-bottom: 5px!important;
        }
        .swal2-actions button[type=button] {
            border-radius: 8px!important;
        }
    </style>
</body>
</html>