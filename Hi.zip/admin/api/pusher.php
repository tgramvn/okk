<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

if ($account)
{
	switch ($act) {
		case 'delete':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$db->Query("DELETE FROM `tb_pusher` WHERE `id` = '$id'");
			die($core->ajaxReturnMsg(true, "Xóa thành công!"));

			break;
		case 'create':

			$app_id = $core->antiSpecialChars($db->Real_Escape_String($_POST['app_id']));
			$cluster = $core->antiSpecialChars($db->Real_Escape_String($_POST['cluster']));
			$key = $core->antiSpecialChars($db->Real_Escape_String($_POST['key']));
			$secret = $core->antiSpecialChars($db->Real_Escape_String($_POST['secret']));

			if (empty($app_id) || empty($cluster) || empty($key) || empty($secret))
			{
				die($core->ajaxReturnMsg(false, "Vui lòng nhập đầy đủ dữ liệu!"));
			}

			$db->Query("INSERT INTO `tb_pusher` SET
				`pusher_app_id` = '$app_id',
				`pusher_cluster` = '$cluster',
				`pusher_key` = '$key',
				`pusher_secret` = '$secret'");


			die($core->ajaxReturnMsg(true, "Thêm tài khoản thành công!"));

			break;
		default:


			break;
	}
}
ob_flush();
?>