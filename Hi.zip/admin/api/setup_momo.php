<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

if ($account)
{
	switch ($act) {
		case 'relogin':

		break;
		case 'update':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$betMin = $core->antiSpecialChars($db->Real_Escape_String($_POST['betMin']));
			$betMax = $core->antiSpecialChars($db->Real_Escape_String($_POST['betMax']));

			$db->Query("UPDATE `tb_momo` SET `betMin` = '$betMin', `betMax` = '$betMax' WHERE `id` = '$id'");

			die($core->ajaxReturnMsg(true, "Cập nhật thành công!"));

			break;
		case 'register':

			$phone = $core->antiSpecialChars($db->Real_Escape_String($_POST['phone']));
			$password = $core->antiSpecialChars($db->Real_Escape_String($_POST['password']));
			$devices = $db->Fetch_Array("SELECT * FROM `tb_devices` ORDER BY RAND() LIMIT 1");

			$data = array(
				'phone' => $phone,
				'device' => $devices['device'],
				'hardware' => $devices['hardware'],
				'facture' => $devices['facture'],
				'SECUREID' => $momo->get_SECUREID(),
				'MODELID' => $devices['MODELID'],
				'imei' => $momo->generateImei(),
				'rkey' => $momo->generateRandom(20),
				'AAID' => $momo->generateImei(),
				'TOKEN' => $momo->get_TOKEN(),
				'password' => $password,
				'proxy' => null
			);

			if (empty($phone) || empty($password))
			{
				die($core->ajaxReturnMsg(false, "Vui lòng nhập đầy đủ dữ liệu!"));
			}

			$result = $momo->SendOTP($data);
			if ($result['status'] == "success")
			{
				if (!$db->Num_Rows("SELECT * FROM `tb_private_momo` WHERE `phone` = '$phone'"))
				{
					$db->Query("INSERT INTO `tb_private_momo` SET
						`token` = '".$core->quickRandom(64)."',
						`phone` = '$phone',
						`info` = '".json_encode($data)."',
						`status` = '3',
						`try` = '0',
						`is_invisible` = '1',
						`time_login` = '".time()."'");

					die($core->ajaxReturnMsg(true, "Gửi mã OTP về ".$phone." thành công!"));
				}
				else
				{
					$db->Query("UPDATE `tb_private_momo` SET `status` = '3', `info` = '".json_encode($data)."' WHERE `phone` = '$phone'");
					die($core->ajaxReturnMsg(true, "Gửi mã OTP về ".$phone." thành công!"));
				}
			}
			else
			{
				die($core->ajaxReturnMsg(false, "Lỗi vui lòng thực hiện lại sau!"));
			}

			break;
		case 'comfirm':

			$phone = $core->antiSpecialChars($db->Real_Escape_String($_POST['phone']));
			$code = $core->antiSpecialChars($db->Real_Escape_String($_POST['code']));
			
			if (empty($phone) || empty($code))
			{
				die($core->ajaxReturnMsg(false, "Vui lòng nhập đầy đủ dữ liệu!"));
			}

			$dataMomo = $db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `phone` = '$phone'");
			$data_old = json_decode($dataMomo['info'], true);
			$hash = hash('sha256', $data_old["phone"] . $data_old["rkey"] . $code);
			$data = $core->addArray($data_old, array('ohash' => $hash));
			$result = $momo->REG_DEVICE_MSG($data);
			if ($result['errorCode'] != 0)
			{
				die($core->ajaxReturnMsg(false, $result));
			}
			else if ($result['errorCode'] == 0 || empty($result['errorCode']))
			{
				$setupKey = $core->addArray($data, array('setupKey' => $result["extra"]["setupKey"])); 
				$getKey = $momo->get_setupKey($result["extra"]["setupKey"], $data);
				$data_new = json_encode($core->addArray($setupKey, array('setupKeyDecrypt' => $getKey)));

				$db->Query("UPDATE `tb_private_momo` SET `info` = '$data_new' WHERE `phone` = '$phone'");
				$result = $momo_ctrl->loginMomo($dataMomo['phone']);
				if ($result['status'] == 'success')
				{
					$db->Query("UPDATE `tb_private_momo` SET `status` = '4', `updated_at` = '".time()."' WHERE `phone` = '$phone'");
					$re_dataMomo = $db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `phone` = '$phone'");
					$db->Query("INSERT INTO `tb_momo` SET
						`name` = '".$re_dataMomo['name']."',
						`phone` = '$phone',
						`bonus` = '0',
						`limitDay` = '25000000',
						`limitMonth` = '80000000',
						`number` = '190',
						`count` = '0',
						`betMin` = '6000',
						`betMax` = '2000000',
						`amountDay` = '0',
						`amountMonth` = '0',
						`status` = 'active'");
					die($core->ajaxReturnMsg(true, "Thêm tài khoản thành công!"));
				}
				else
				{
					die($core->ajaxReturnMsg(false, $result));
				}
			}

			break;
		case 'delete':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['account_id']));

			$pmomo = $db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `id` = '$id'");
			$momo = $db->Fetch_Array("SELECT * FROM `tb_momo` WHERE `phone` = '".$pmomo['phone']."'");

			$db->Fetch_Array("DELETE FROM `tb_private_momo` WHERE `id` = '".$pmomo['id']."'");
			$db->Fetch_Array("DELETE FROM `tb_momo` WHERE `id` = '".$momo['id']."'");

			die($core->ajaxReturnMsg(true, "Xóa thành công!"));

			break;
		default:
		
		break;
	}
}

ob_flush();
?>