<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

if (!$account)
{
	$username = $core->antiSpecialChars($db->Real_Escape_String($_POST['username']));
	$password = $core->antiSpecialChars($db->Real_Escape_String($_POST['password']));

	if (empty($username) || empty($password))
	{
		die($core->ajaxReturnMsg(false, 'Vui lòng nhập đầy đủ dữ liệu!'));
	}
	if ($users->isLogin($username, $password))
	{
		$_SESSION['user_id'] = $username;
		$_SESSION['user_password'] = md5(md5($password));
		die($core->ajaxReturnMsg(true, 'Đăng nhập thành công, chờ chuyển hướng...'));
	}
	else
	{
		die($core->ajaxReturnMsg(false, 'Thông tin đăng nhập không chính xác!'));
	}
}

ob_flush();
?>

