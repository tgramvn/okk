<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

if ($account)
{
	$momo_account = $core->antiSpecialChars($db->Real_Escape_String($_POST['momo_account']));
	$phone = $core->antiSpecialChars($db->Real_Escape_String($_POST['phone']));
	$cash = $core->antiSpecialChars($db->Real_Escape_String($_POST['cash']));
	$content = $core->antiSpecialChars($db->Real_Escape_String($_POST['content']));
	$password = $core->antiSpecialChars($db->Real_Escape_String($_POST['password']));

	if (empty($phone) || empty($cash) || empty($password))
	{
		die($core->ajaxReturnMsg(false, "Vui lòng nhập đầy đủ dữ liệu!"));
	}
	
	if (md5(md5($password)) != $datauser['password'])
	{
		die($core->ajaxReturnMsg(false, "Mật khẩu không chính xác!"));
	}

	$m_data = $db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `phone` = '$momo_account'");

	$response = $momo_ctrl->sendMoneyMomo($m_data, $cash, $content, $phone);

	if (empty($response) || $response == null || $response["status"] == "error")
	{
		die($core->ajaxReturnMsg(false, $response["message"]));
	}
	else
	{
		$db->Query("INSERT INTO `tb_momo_transfer_history` SET
			`momo_txn` = '".$response["data"]['tranId']."',
			`momo_phone` = '".$response["data"]['ownerNumber']."',
			`receiver_name` = '".$response["data"]['partnerName']."',
			`receiver_phone` = '".$response["data"]['partnerId']."',
			`amount` = '".$response["data"]['amount']."',
			`content` = '$content',
			`created_at` = '".time()."'");
		die($core->ajaxReturnMsg(true, "Giao dịch hoàn thành!"));
	}
}

ob_flush();
?>