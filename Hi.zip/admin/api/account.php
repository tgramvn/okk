<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

if ($account)
{
	switch ($act) {
		case 'load':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$row = $db->Fetch_Array("SELECT * FROM `tb_users` WHERE `id` = '$id'");
			$array = array(
				'id' => $row['id'],
				'full_name' => $core->formatExportDatabase($row['full_name']),
				'username' => $row['username']
			);
			die(json_encode($array));

			break;
		case 'update':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$fullname = $core->antiSpecialChars($db->Real_Escape_String($_POST['fullname']));
			$username = $core->antiSpecialChars($db->Real_Escape_String($_POST['username']));
			$password = $core->antiSpecialChars($db->Real_Escape_String($_POST['password']));
			if (empty($password))
			{
				$db->Query("UPDATE `tb_users` SET
					`full_name` = '$fullname',
					`username` = '$username' WHERE `id` = '$id'");
			}
			else
			{

				$db->Query("UPDATE `tb_users` SET
					`full_name` = '$fullname',
					`username` = '$username',
					`password` = '".md5(md5($password))."' WHERE `id` = '$id'");
			}

			die($core->ajaxReturnMsg(true, "Cập nhật thành công!"));

			break;
		case 'delete':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$db->Query("DELETE FROM `tb_users` WHERE `id` = '$id'");
			die($core->ajaxReturnMsg(true, "Xóa thành công!"));

			break;
		case 'create':

			$fullname = $core->antiSpecialChars($db->Real_Escape_String($_POST['fullname']));
			$username = $core->antiSpecialChars($db->Real_Escape_String($_POST['username']));
			$password = $core->antiSpecialChars($db->Real_Escape_String($_POST['password']));
			$repassword = $core->antiSpecialChars($db->Real_Escape_String($_POST['repassword']));

			if (empty($fullname) || empty($username) || empty($password) || empty($repassword))
			{
				die($core->ajaxReturnMsg(false, "Vui lòng nhập đầy đủ dữ liệu!"));
			}

			if ($password != $repassword)
			{
				die($core->ajaxReturnMsg(false, "Mật khẩu không trùng khớp!"));
			}

			$db->Query("INSERT INTO `tb_users` SET
				`username` = '$username',
				`password` = '".md5(md5($password))."',
				`full_name` = '$fullname'");


			die($core->ajaxReturnMsg(true, "Thêm tài khoản thành công!"));

			break;
		default:


			break;
	}
}
ob_flush();
?>