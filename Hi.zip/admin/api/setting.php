<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

if ($account)
{
    $top_day = "0";
    $top_day_player_amount = "0";
    $top_day_player_bonus = "0";
	$top_day_virtual_win = "0";
	$top_day_virtual_amount = "0";
	$top_day_virtual_phone = "0";
	foreach ($_POST as $key => $value)
    {  
        if (strpos($key, "ps_day"))
        {
            $top_day = $top_day.'|'.$value;
        }
        else if (strpos($key, "er_amount"))
        {
            $top_day_player_amount = $top_day_player_amount.'|'.$value;
        }
        else if (strpos($key, "er_bonus"))
        {
            $top_day_player_bonus = $top_day_player_bonus.'|'.$value;
        }
    	else if (strpos($key, "l_amount"))
    	{
    		$top_day_virtual_amount = $top_day_virtual_amount.'|'.$value;
    	}
    	else if (strpos($key, "l_phone"))
    	{
    		$top_day_virtual_phone = $top_day_virtual_phone.'|'.$value;
    	}
    	else if (strpos($key, "l_win"))
    	{
    		$top_day_virtual_win = $top_day_virtual_win.'|'.$value;
    	}
    	else
    	{
    		$db->Query("UPDATE `tb_settings` SET `value` = '$value' WHERE `name` = '$key'");
    	}
	}

    $db->Query("UPDATE `tb_settings` SET `value` = '$top_day' WHERE `name` = 'top_day'");
    $db->Query("UPDATE `tb_settings` SET `value` = '$top_day_player_amount' WHERE `name` = 'top_day_player_amount'");
    $db->Query("UPDATE `tb_settings` SET `value` = '$top_day_player_bonus' WHERE `name` = 'top_day_player_bonus'");

	$db->Query("UPDATE `tb_settings` SET `value` = '$top_day_virtual_win' WHERE `name` = 'top_day_virtual_win'");
	$db->Query("UPDATE `tb_settings` SET `value` = '$top_day_virtual_amount' WHERE `name` = 'top_day_virtual_amount'");
	$db->Query("UPDATE `tb_settings` SET `value` = '$top_day_virtual_phone' WHERE `name` = 'top_day_virtual_phone'");
	
    die($core->ajaxReturnMsg(true, "Thay đổi thành công"));
}

ob_flush();
?>