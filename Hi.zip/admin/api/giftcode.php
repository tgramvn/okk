<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

if ($account)
{
	switch ($act) {
		case 'create':

			$gift_code = $core->antiSpecialChars($db->Real_Escape_String($_POST['gift_code']));
			$gift_amount = $core->antiSpecialChars($db->Real_Escape_String($_POST['gift_amount']));

			$db->Query("INSERT INTO `tb_giftcode` SET `code` = '$gift_code', `amount` = '$gift_amount', `created_at` = '".time()."', `state_at` = 'active'");

			die($core->ajaxReturnMsg(true, "Tạo GiftCode thành công!"));

			break;
		case 'delete':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['gift_id']));
			$db->Fetch_Array("DELETE FROM `tb_giftcode` WHERE `id` = '$id'");

			die($core->ajaxReturnMsg(true, "Xóa thành công!"));

			break;
		default:

			break;
	}

}

ob_flush();
?>