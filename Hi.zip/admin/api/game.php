<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

if ($account)
{
	switch ($act) {
		case 'update':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$description = $db->Real_Escape_String($_POST['description']);
			$content = $core->antiSpecialChars($db->Real_Escape_String($_POST['content']));
			$amount = $core->antiSpecialChars($db->Real_Escape_String($_POST['amount']));

			$row = $db->Fetch_Array("SELECT * FROM `tb_game` WHERE `id` = '$id'");

			$db->Query("UPDATE `tb_game` SET `description` = '$description' WHERE `gameType` = '".$row['gameType']."'");
			$db->Query("UPDATE `tb_game` SET `content` = '$content' WHERE `gameType` = '".$row['gameType']."'");
			$db->Query("UPDATE `tb_game` SET `amount` = '$amount' WHERE `gameType` = '".$row['gameType']."'");

			die($core->ajaxReturnMsg(true, "Cập nhật thành công!"));

			break;
		case 'hide':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$row = $db->Fetch_Array("SELECT * FROM `tb_game` WHERE `id` = '$id'");
			
			$db->Query("UPDATE `tb_game` SET `enable` = '0' WHERE `gameType` = '".$row['gameType']."'");
			die($core->ajaxReturnMsg(true, "Cập nhật thành công!"));

			break;
		case 'show':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$row = $db->Fetch_Array("SELECT * FROM `tb_game` WHERE `id` = '$id'");

			$db->Query("UPDATE `tb_game` SET `enable` = '1' WHERE `gameType` = '".$row['gameType']."'");

			die($core->ajaxReturnMsg(true, "Cập nhật thành công!"));

			break;
		default:

			break;
	}

}
ob_flush();
?>