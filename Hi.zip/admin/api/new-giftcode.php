<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

function createGiftCode($database = null)
{
	$code = substr(strtoupper(bin2hex(random_bytes(8))), 0, 8);
	while($database->Num_Rows("SELECT * FROM `tb_giftcode_cash` WHERE `code` = '$code'"))
	{
		$rand = substr(strtoupper(bin2hex(random_bytes(8))), 0, 8);
		if (!$database->Num_Rows("SELECT * FROM `tb_giftcode_cash` WHERE `code` = '$code'"))
		{
			$code = $rand;
			break;
		}
	}
	return $code;
}

if ($account)
{
	switch ($act) {
		case 'create':

			$amount = $core->antiSpecialChars($db->Real_Escape_String($_POST['amount']));
			$count = $core->antiSpecialChars($db->Real_Escape_String($_POST['count']));
			$exp = $core->antiSpecialChars($db->Real_Escape_String($_POST['exp']));

			if (empty($amount))
			{
				die($core->ajaxReturnMsg(false, "Vui lòng nhập đầy đủ dữ liệu!"));
			}

			$time = time() + ($exp * (24*60*60));

			$db->Query("INSERT INTO `tb_giftcode_cash` SET
				`code` = '".createGiftCode($db)."',
				`amount` = '$amount',
				`count` = '$count',
				`created_at` = '".time()."',
				`expired_at` = '$time',
				`state_at` = 'active'");

			die($core->ajaxReturnMsg(true, "Thêm GiftCode thành công!"));

			break;
		case 'delete':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$db->Query("DELETE FROM `tb_giftcode_cash` WHERE `id` = '$id'");
			die($core->ajaxReturnMsg(true, "Xóa thành công!"));
			
			break;
		default:

			break;
	}
}
ob_flush();
?>