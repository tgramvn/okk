<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

if ($account)
{
	switch ($act) {
		case 'hide':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));

			$db->Query("UPDATE `tb_private_momo` SET `is_invisible` = '0' WHERE `id` = '$id'");

			die($core->ajaxReturnMsg(true, "Cập nhật thành công!"));

			break;
		case 'show':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));

			$db->Query("UPDATE `tb_private_momo` SET `is_invisible` = '1' WHERE `id` = '$id'");

			die($core->ajaxReturnMsg(true, "Cập nhật thành công!"));

			break;
		case 'load':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$row = $db->Fetch_Array("SELECT * FROM `tb_momo` WHERE `id` = '$id'");
			$array = array(
				'id' => $row['id'],
				'betMin' => $row['betMin'],
				'betMax' => $row['betMax'],
				'limitDay' => $row['limitDay'],
				'limitMonth' => $row['limitMonth']
			);
			die(json_encode($array));


			break;
		case 'update':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$betMin = $core->antiSpecialChars($db->Real_Escape_String($_POST['betMin']));
			$betMax = $core->antiSpecialChars($db->Real_Escape_String($_POST['betMax']));
			$limitDay = $core->antiSpecialChars($db->Real_Escape_String($_POST['limitDay']));
			$limitMonth = $core->antiSpecialChars($db->Real_Escape_String($_POST['limitMonth']));

			$db->Query("UPDATE `tb_momo` SET
				`betMin` = '$betMin',
				`betMax` = '$betMax',
				`limitDay` = '$limitDay',
				`limitMonth` = '$limitMonth' WHERE `id` = '$id'");

			die($core->ajaxReturnMsg(true, "Cập nhật thành công!"));

			break;
		case 'delete':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));

			$pmomo = $db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `id` = '$id'");
			$momo = $db->Fetch_Array("SELECT * FROM `tb_momo` WHERE `phone` = '".$pmomo['phone']."'");

			$db->Fetch_Array("DELETE FROM `tb_private_momo` WHERE `id` = '".$pmomo['id']."'");
			$db->Fetch_Array("DELETE FROM `tb_momo` WHERE `id` = '".$momo['id']."'");

			die($core->ajaxReturnMsg(true, "Xóa thành công!"));

			break;
		default:

			break;
	}
}
ob_flush();
?>