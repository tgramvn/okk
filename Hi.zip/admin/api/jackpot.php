<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

if ($account)
{
	switch ($act) {
		case 'delete-win':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$db->Query("DELETE FROM `tb_jackpot_session` WHERE `id` = '$id'");

			die($core->ajaxReturnMsg(true, "Xóa thành công!"));

			break;
		case 'delete-player':

			$id = $core->antiSpecialChars($db->Real_Escape_String($_POST['id']));
			$db->Query("DELETE FROM `tb_jackpot_player` WHERE `id` = '$id'");

			die($core->ajaxReturnMsg(true, "Xóa thành công!"));

			break;
		default:

			break;
	}

}

ob_flush();
?>