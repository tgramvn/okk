<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../incfiles/init.php');

if(!$account)
{
    header('location: '.$core->formatExportDatabase($core->isHomeSetting('website_url')).'/admin/login');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <base href="<?php echo $core->formatExportDatabase($core->isHomeSetting('website_url')); ?>">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="<?php echo $core->formatExportDatabase($core->isHomeSetting('description')); ?>">
    <meta name="keywords" content="<?php echo $core->formatExportDatabase($core->isHomeSetting('keywords')); ?>">
    <meta property="og:description" content="Chẵn Lẻ MoMo - Mini game giải trí chẵn lẻ Momo uy tín và hệ thống thanh toán tự động trong 30s, kiếm Tiền Nhanh Chóng chỉ trong 1 nốt nhạc.">
    <meta property="og:image" content="https://file.coin98.com/insights/Vi%CC%81-MOMO.jpg">
    <link rel="shortcut icon" href="<?php echo $core->formatExportDatabase($core->isHomeSetting('favicon')); ?>" type="image/x-icon">
    <title><?php echo $core->formatExportDatabase($core->isHomeSetting('title')); ?></title>
    <link rel="stylesheet" href="../assets/css/app.css">
    <link rel="stylesheet" href="../assets/plugins/notify/css/jquery.growl.css">
    <link rel="stylesheet" href="../assets/css/richtext.css">
    <link rel="stylesheet" href="../assets/plugins/select2/select2.min.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style type="text/css">
    	@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700&display=swap');

    	.swal2-container {
			z-index: 100001 !important;
		}
		.swal2-popup {
			font-family: 'Nunito', sans-serif!important;
			padding-bottom: 10px!important;
			border-radius: 18px!important;
			box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
		}
		.swal2-actions {
			margin: 15px 0 0!important;
			padding-top: 10px!important;
			border-top: 1px solid #eee;
		}
		.swal2-title {
			margin-bottom: 5px!important;
		}
		.swal2-actions button[type=button] {
			border-radius: 8px!important;
		}
        .card-table tr td:first-child,
        .card-table tr th:first-child {
            padding-left: 0.75rem;
        }

        .card-table tr td:last-child,
        .card-table tr th:last-child {
            padding-right: 0.75rem;
        }

        label {
            font-weight: 600;
        }

    </style>
</head>
<div id="global-loader"></div>
<div class="page">
    <div class="page-main">
        <div class="header">
            <div class="container">
                <div class="d-flex">
                    <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse"
                        data-target="#headerMenuCollapse">
                        <span class="header-toggler-icon"></span>
                    </a>
                    <a class="header-brand" href="/" style="color:#fff;font-weight:bold">
                        <i class="fab fa-opencart" style="font-size: 25px;"></i> <?php echo $core->formatExportDatabase($core->isHomeSetting('website_name')); ?></a>
                </div>
            </div>
        </div>
        <div class="admin-navbar sticky" id="headerMenuCollapse">
            <div class="container">
                <ul class="nav">
                    <li class="nav-item with-sub" data-link="admin/dashboard">
                        <a class="nav-link scroll-to" href="javascript:void(0);">
                            <i class="fas fa-home"></i>
                            <span>Trang Chủ</span>
                        </a>
                    </li>
                    <li class="nav-item with-sub" data-link="admin/system">
                        <a class="nav-link scroll-to" href="javascript:void(0);">
                            <i class="fas fa-cogs"></i>
                            <span>Cài Đặt Hệ Thống</span>
                        </a>
                    </li>
                    <li class="nav-item with-sub">
                        <a class="nav-link scroll-to" href="javascript:void(0);" id="miniGameDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-gamepad"></i>
                            <span>Mini Game</span>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="miniGameDropdown">
                            <a class="dropdown-item" href="javascript:void(0);" data-link="admin/game">Quản Lý Game</a>
                            <a class="dropdown-item" href="javascript:void(0);" data-link="admin/list-player">Danh Sách Người Chơi</a>
                            <a class="dropdown-item" href="javascript:void(0);" data-link="admin/jackpot-player">Danh Sách Chơi Nổ Hũ</a>
                            <a class="dropdown-item" href="javascript:void(0);" data-link="admin/jackpot-history">Lịch Sử Nổ Hũ</a>
                            <!-- <a class="dropdown-item" href="javascript:void(0);" data-link="admin/muster">Danh Sách Điểm Danh</a> -->
                        </div>
                    </li>
                    <li class="nav-item with-sub">
                        <a class="nav-link scroll-to" href="javascript:void(0);" id="walletDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-wallet"></i>
                            <span>Ví Momo</span>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="walletDropdown">
                        	<a class="dropdown-item" href="javascript:void(0);" data-link="admin/momo">Danh Sách Tài Khoản</a>
                        	<a class="dropdown-item" href="javascript:void(0);" data-link="admin/transfer">Chuyển Tiền</a>
                        	<a class="dropdown-item" href="javascript:void(0);" data-link="admin/history">Lịch Sử Giao Dịch</a>
                        	<a class="dropdown-item" href="javascript:void(0);" data-link="admin/transfer-history">Lịch Sử Chuyển Tiền</a>
                        </div>
                    </li>
                    <li class="nav-item with-sub">
                        <a class="nav-link scroll-to" href="javascript:void(0);" id="toolDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-tools"></i>
                            <span>Công Cụ</span>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="toolDropdown">
                            <a class="dropdown-item" href="javascript:void(0);" data-link="admin/spam-transfer">Spam Chuyển Tiền</a>
                            <a class="dropdown-item" href="javascript:void(0);" data-link="admin/new-giftcode">GiftCode v2</a>
                            <a class="dropdown-item" href="javascript:void(0);" data-link="admin/pusher">Cài Đặt Pusher</a>
                            <a class="dropdown-item" href="javascript:void(0);" data-link="admin/logs">Admin Logs</a>
                        </div>
                    </li>
                    <li class="nav-item with-sub" data-link="admin/list-account">
                        <a class="nav-link scroll-to" href="javascript:void(0);">
                            <i class="fas fa-user"></i>
                            <span>Danh Sách Tài Khoản</span>
                        </a>
                    </li>
                    <li class="nav-item with-sub">
                        <a class="nav-link scroll-to" href="/admin/logout">
                            <i class="fas fa-sign-out"></i>
                            <span>Đăng Xuất</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <main class="container">
        	<div class="mainbar"></div>
        	<div class="web-content">
        		
        	</div>
        </main>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 mt-3 mt-lg-0 text-center">
                <b><?php echo $core->formatExportDatabase($core->isHomeSetting('website_name')); ?></b> ©
                <script>document.write(new Date().getFullYear())</script> -
                <script>document.write(new Date().getFullYear() + 2)</script>
            </div>
        </div>
    </div>
</footer>
<a href="#top" id="back-to-top" style="display: inline;"><i class="fa fa-angle-up"></i></a>
<script src="../assets/js/vendors/jquery-3.2.1.min.js"></script>
<script src="../assets/js/vendors/popper.min.js"></script>
<script src="../assets/js/vendors/bootstrap.min.js"></script>
<script src="../assets/js/vendors/jquery.sparkline.min.js"></script>
<script src="../assets/js/sticky.js"></script>
<script src="../assets/js/clipboard.js"></script>
<script src="../assets/js/jquery.mousewheel.min.js"></script>
<script src="../assets/plugins/notify/js/rainbow.js"></script>
<script src="../assets/plugins/notify/js/jquery.growl.js"></script>
<script src="../assets/js/jquery.richtext.js"></script>
<script src="../assets/plugins/select2/select2.full.min.js"></script>
<script src="../assets/plugins/datatable/jquery.dataTables.min.js"></script>
<script src="../assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
<script src="../assets/plugins/pusher/pusher.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="../assets/js/app_admin.js"></script>
<script type="text/javascript">
    let appKey = "<?php echo $core->isHomeSetting('pusher_key'); ?>";
</script>
<script src="../assets/js/love.js"></script>
<script src="../assets/js/main.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
        
        loadFileFormUrl("admin/dashboard");

		$(".nav li.nav-item div a").click(function () {
			var url = $(this).data("link");
			loadFileFormUrl(url);
		});

		$(".nav li.nav-item").click(function () {
			var url = $(this).data("link");
			loadFileFormUrl(url);
		});
	});

	function SwalAlert(text, icon) {
		Swal.fire({
			icon,
			title: "Thông báo",
			html: text,
            confirmButtonText: "Đóng",
	        confirmButtonColor: '#3085d6',
		});
	}

    function initFormAjax(element, callback) {
        $(element).submit(function (e) {
            e.preventDefault();
            let _this = this;
            let url = $(_this).attr("action");
            let method = $(_this).attr("method");
            let data = $(_this).serialize();
            $.ajax({
                url: url,
                type: method,
                data: data,
                dataType: "json",
                beforeSend: function(){
                },
                success: function (response) {
                    if (response.status == true) {
                        callback(response);
                    }
                    else {
                        SwalAlert(
                            response.message,
                            response.status == true ? "success" : "error"
                        );
                    }
                },
                error: function (error) {
                    console.log(error);
                }
            });
        });
    }
	
	function loadFileFormUrl(url) {
		if (url) {
			$.ajax({
				url: '/' + url,
				type: 'GET',
				data: { }
			}).done(function(data) {
				$('.web-content').html(data).slideDown(2000);
			}).fail(function() {
				console.log("error");
			});
		}
	}
</script>