<!doctype html>
<html lang="en">

<head>
    <base href="https://clmm.buzz">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="robots" content="noindex, nofollow" />
    <title>Không Tìm Thấy Trang</title>
    <link rel="shortcut icon" href="../assets/images/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="../assets/css/app.css">
    <link href="../assets/plugins/notify/css/jquery.growl.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/richtext.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../assets/js/vendors/jquery-3.2.1.min.js"></script>
</head>

<body class="login-img">
    <div id="global-loader" style="display: none;"></div>
    <div class="page h-100">
        <div class="page-content error-page">
            <div class="container text-center">
                <div class="error-template">
                    <h1 class="display-1 text-white mb-5"> 404!</h1>
                    <div class="error-details text-transparent">Đã xảy ra lỗi, không tìm thấy trang mà bạn yêu cầu!
                    </div>
                    <div class="error-actions mt-5"> <a class="btn btn-secondary" href="../">
                            Trang Chủ</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>