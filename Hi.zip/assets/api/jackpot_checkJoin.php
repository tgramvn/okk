<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
header('Content-Type: application/json');

$phone = $core->antiSpecialChars($db->Real_Escape_String($_POST['phone']));

if (strlen($phone) < 10 || strlen($phone) > 10)
{
	$arr_total = array(
		'success' => false,
		'message' => 'Số điện thoại đăng ký không hợp lệ!'
	);
	die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
}

$query = "SELECT * FROM `tb_jackpot_player` WHERE FROM_UNIXTIME(`created_at`, '%Y-%m-%d') = CURDATE() AND `phone` = '$phone'";

if ($db->Num_Rows($query))
{
	$row = $db->Fetch_Array($query);
	$arr_total = array(
		'success' => true,
		'message' => 'Thành công!',
		'data' => array(
			'isJoin' => 1,
			'time' => date("d-m-Y H:i:s", $row['created_at'])
		)
	);
	die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
}
else
{
	$arr_total = array(
		'success' => true,
		'message' => 'Thành công!',
		'data' => array(
			'isJoin' => 0
		)
	);
	die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
}

ob_flush();
?>