<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../../incfiles/init.php');



$r_amount = array();
for ($i = 0; $i <= 2; $i++)
{
	for ($x = 0; $x <= 9; $x++)
	{
		if ($i == 0)
		{
			$rekey = $x + 1;
		}
		else
		{
			$rekey = $x;
		}
		$r_amount[] = (($i == 0) ? '' : $i).$rekey.'000';
	}
}
$amountRandId = array_rand($r_amount);
$amount_in = $r_amount[$amountRandId];
$re_amount = (6000 - $amount_in);
$amount_req = ($amount_in < 6000) ? $amount_in + $re_amount : $amount_in;
$tel = $core->cloneNumPhone();

if ($core->isHomeSetting('bot_autogame') == 'On')
{
	$dataMomo = $db->Fetch_Array("SELECT * FROM `tb_momo` ORDER BY RAND() LIMIT 1");
	$count_bot = $db->Num_Rows("SELECT * FROM `tb_history` WHERE `is_bot` = '1'");
	if ($count_bot > 20)
	{
		$count_del = $count_bot - 10;
		$db->Query("DELETE FROM `tb_history` WHERE `is_bot` = '1' ORDER BY `id` ASC LIMIT $count_del");
	}
	if (time() > $dataMomo['cron_rand_time'])
	{
		if ($dataMomo['id'] == 1)
		{
			$time = rand(100, 300) + time();
		}
		else if ($dataMomo['id'] == 2)
		{
			$time = rand(200, 400) + time();
		}
		else if ($dataMomo['id'] == 3)
		{
			$time = rand(300, 600) + time();
		}
		else if ($dataMomo['id'] == 4)
		{
			$time = rand(400, 800) + time();
		}
		
		$db->Query("UPDATE `tb_momo` SET `cron_rand_time` = '$time' WHERE `id` = '".$dataMomo['id']."'");
		$game = $db->Fetch_Array("SELECT * FROM `tb_game` WHERE `id` = '".rand(1, 4)."'");
		$db->Query("INSERT INTO `tb_history` SET
			`is_bot` = '1',
			`momo_txn` = '',
			`phone_player` = '$tel',
			`phone_recv` = '',
			`gameId` = '".$game['id']."',
			`money` = '".$amount_req."',
			`bonus` = '".($amount_req * $game['amount'])."',
			`content` = '".$game['content']."',
			`created_at` = '".time()."',
			`pay_at` = 'done',
			`stated_at` = 'win'");
		$momo_ctrl->updateRealTimeMomo(($amount_req * $game['amount']), $dataMomo['phone']);
		$core->pushNotification($core->maskNumPhone($tel), ($amount_req * $game['amount']));
	}
}

ob_flush();
?>