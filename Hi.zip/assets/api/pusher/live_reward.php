<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../../incfiles/init.php');

$time = time();
$my_website = $core->formatExportDatabase($core->isHomeSetting('website_name'));
$req = $db->Query("SELECT * FROM `tb_history` WHERE `is_bot` != '1' AND `stated_at` = 'win' AND `pay_at` = 'wait'");
while ($history = mysqli_fetch_array($req))
{
	$dataMomo = $db->Fetch_Array("SELECT * FROM `tb_private_momo` INNER JOIN `tb_momo` ON `tb_private_momo`.`phone` = `tb_momo`.`phone` WHERE `tb_private_momo`.`phone` = '".$history['phone_recv']."'");

	if (($history['created_at'] + 60) > time() && (int)$history['money'] < 40000 && (int)$history['money'] >= (int)$dataMomo['betMin'] && (int)$history['money'] <= (int)$dataMomo['betMax'])
	{
		if ($core->isHomeSetting('jackpot') == 'Yes')
		{
			if ($db->Num_Rows("SELECT * FROM `tb_jackpot_player` WHERE FROM_UNIXTIME(`created_at`, '%Y-%m-%d') = CURDATE() AND `phone` = '".$history['phone_player']."'"))
			{
				$jackpot_num = explode(" - ", $core->isHomeSetting('jackpot_code'));
				$jackpot_content = $my_website." - Nổ Hũ Giao Dịch: ".$history['momo_txn'];
				for ($i = 0; $i < count($jackpot_num); $i++)
				{
					if (substr((string)$his['momo_txn'], '-'.strlen($jackpot_num[$i])) == $jackpot_num[$i])
					{
						if (!$db->Num_Rows("SELECT * FROM `tb_task` WHERE `momo_txn` = '".$history['momo_txn']."'"))
						{
							$reward = ($history['bonus'] - (int)$core->isHomeSetting('jackpot_amount_minus')) + (int)$core->isHomeSetting('jackpot_amount');
							$db->Query("INSERT INTO `tb_jackpot_session` SET `phone` = '".$history['phone_player']."', `amount` = '$reward', `created_at` = '$time'");
							$response = $momo_ctrl->sendMoneyMomo($dataMomo, $reward, $jackpot_content, $history['phone_player']);

							if (empty($response) || $response == null || $response["status"] == "error")
							{
								$db->Query("DELETE FROM `tb_task` WHERE `momo_txn` = '".$history['momo_txn']."'");
							}
							else
							{
								$db->Query("UPDATE `tb_task` SET `updated_at` = '$time' WHERE `momo_txn` = '".$history['momo_txn']."'");
								$db->Query("INSERT INTO `tb_momo_transfer_history` SET
									`momo_txn` = '".$response["data"]['tranId']."',
									`momo_phone` = '".$response["data"]['ownerNumber']."',
									`receiver_name` = '".$response["data"]['partnerName']."',
									`receiver_phone` = '".$response["data"]['partnerId']."',
									`amount` = '".$response["data"]['amount']."',
									`content` = '$content',
									`created_at` = '$time'");
								$db->Query("UPDATE `tb_history` SET `pay_at` = 'done' WHERE `id` = '".$history['id']."'");
							}
						}
					}
				}
			}
			else
			{
				if (!$db->Num_Rows("SELECT * FROM `tb_task` WHERE `momo_txn` = '".$history['momo_txn']."'"))
				{
					$content = $my_website." trả thưởng giao dịch: ".$history['momo_txn'];
					$db->Query("INSERT INTO `tb_task` SET `momo_txn` = '".$history['momo_txn']."', `created_at` = '$time'");
					$reward = ($history['bonus'] / 100) * $core->isHomeSetting('refund_win');
					$response = $momo_ctrl->sendMoneyMomo($dataMomo, $reward, $content, $history['phone_player']);

					if (empty($response) || $response == null || $response["status"] == "error")
					{
						$db->Query("DELETE FROM `tb_task` WHERE `momo_txn` = '".$history['momo_txn']."'");
					}
					else
					{
						$db->Query("UPDATE `tb_task` SET `updated_at` = '$time' WHERE `momo_txn` = '".$history['momo_txn']."'");
						$db->Query("INSERT INTO `tb_momo_transfer_history` SET
							`momo_txn` = '".$response["data"]['tranId']."',
							`momo_phone` = '".$response["data"]['ownerNumber']."',
							`receiver_name` = '".$response["data"]['partnerName']."',
							`receiver_phone` = '".$response["data"]['partnerId']."',
							`amount` = '".$response["data"]['amount']."',
							`content` = '$content',
							`created_at` = '$time'");
						$db->Query("UPDATE `tb_history` SET `pay_at` = 'done' WHERE `id` = '".$history['id']."'");
					}
				}
			}
		}
		else
		{
			if (!$db->Num_Rows("SELECT * FROM `tb_task` WHERE `momo_txn` = '".$history['momo_txn']."'"))
			{
				$content = $my_website." trả thưởng giao dịch: ".$history['momo_txn'];
				$db->Query("INSERT INTO `tb_task` SET `momo_txn` = '".$history['momo_txn']."', `created_at` = '$time'");
				$reward = ($history['bonus'] / 100) * $core->isHomeSetting('refund_win');
				$response = $momo_ctrl->sendMoneyMomo($dataMomo, $reward, $content, $history['phone_player']);

				if (empty($response) || $response == null || $response["status"] == "error")
				{
					$db->Query("DELETE FROM `tb_task` WHERE `momo_txn` = '".$history['momo_txn']."'");
				}
				else
				{
					$db->Query("UPDATE `tb_task` SET `updated_at` = '$time' WHERE `momo_txn` = '".$history['momo_txn']."'");
					$db->Query("INSERT INTO `tb_momo_transfer_history` SET
						`momo_txn` = '".$response["data"]['tranId']."',
						`momo_phone` = '".$response["data"]['ownerNumber']."',
						`receiver_name` = '".$response["data"]['partnerName']."',
						`receiver_phone` = '".$response["data"]['partnerId']."',
						`amount` = '".$response["data"]['amount']."',
						`content` = '$content',
						`created_at` = '$time'");
					$db->Query("UPDATE `tb_history` SET `pay_at` = 'done' WHERE `id` = '".$history['id']."'");
				}
				$db->Query("INSERT INTO `tb_logs` SET `action` = 'SEND_MONEY_MOMO', `content` = '".json_encode($response, JSON_UNESCAPED_UNICODE)."', `created_at` = '$time'");
			}
		}
	}
}


ob_flush();
?>
