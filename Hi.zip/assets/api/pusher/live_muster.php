<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../../incfiles/init.php');

$curTime = time();
$muster_array = array();
$date = date("H", $curTime);
if ($date >= $core->isHomeSetting('muster_start') && $date <= $core->isHomeSetting('muster_end'))
{
	$row = $db->Fetch_Array("SELECT * FROM `tb_muster` WHERE `state_at` = 'active' ORDER BY `id` DESC LIMIT 1");
	$count = $db->Num_Rows("SELECT * FROM `tb_muster_player` WHERE `muster_id` = '".$row['code']."'");
	$win = $db->Fetch_Array("SELECT * FROM `tb_muster_player` WHERE `is_win` = '1' ORDER BY `id` DESC LIMIT 1");
	$bonus = $db->Fetch_Array("SELECT SUM(`bonus`) FROM `tb_muster`")['SUM(`bonus`)'];
	$time_check = $row['created_at'] + $core->isHomeSetting('muster_time');
	$min_money = $core->isHomeSetting('muster_money_start');
	$max_money = $core->isHomeSetting('muster_money_end');

	$muster_array = array(
		'code' => (int)$row['code'],
		'count' => (int)$count,
		'win' => $core->maskNumPhone($win['phone']),
		'bonus' => (int)$bonus,
		'second' => (int)$time_check - $curTime
	);

	if ($core->isHomeSetting('bot_automuster') == 'On')
	{
		if (time() > (int)$time_check)
		{
			$db->Query("INSERT INTO `tb_muster_player` SET
				`muster_id` = '".$row['code']."',
				`phone` = '".$core->cloneNumPhone()."',
				`is_win` = '1',
				`created_at` = '$curTime'");
			$db->Query("INSERT INTO `tb_muster` SET
				`code` = '".$core->createCode()."',
				`bonus` = '".rand($min_money, $max_money)."',
				`created_at` = '$curTime',
				`state_at` = 'active'");
		}
	}
	else
	{
		if (time() > (int)$time_check)
		{
			$info_users = $db->Fetch_Array("SELECT * FROM `tb_muster_player` WHERE `muster_id` = '".$row['code']."' ORDER BY RAND() LIMIT 1");
			$dataMomo = $db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `is_invisible` = '1' ORDER BY RAND() LIMIT 1");
			$content = 'Trúng thưởng điểm danh '.$row['code'];
			$response = $momo_ctrl->sendMoneyMomo($dataMomo, $row['bonus'], $content, $info_users['phone']);
			if (empty($response) || $response == null || $response["status"] == "error")
			{
				
			}
			else
			{
				$db->Query("INSERT INTO `tb_muster` SET
					`code` = '".$core->createCode()."',
					`bonus` = '".rand($min_money, $max_money)."',
					`created_at` = '$curTime',
					`state_at` = 'active'");
			}
		}
	}
}
else
{
	$row = $db->Fetch_Array("SELECT * FROM `tb_muster` ORDER BY `id` DESC LIMIT 1");
	$count = $db->Num_Rows("SELECT * FROM `tb_muster_player` WHERE `muster_id` = '".$row['code']."'");
	$win = $db->Fetch_Array("SELECT * FROM `tb_muster_player` WHERE `is_win` = '1' ORDER BY `id` DESC LIMIT 1");
	$bonus = $db->Fetch_Array("SELECT SUM(`bonus`) FROM `tb_muster`")['SUM(`bonus`)'];

	$muster_array =  array(
		'code' => (int)$row['code'],
		'count' => (int)$count,
		'win' => $core->maskNumPhone($win['phone']),
		'bonus' => (int)$bonus,
		'second' => 0
	);
}

$core->pusher('musterData', $muster_array);

ob_flush();
?>
