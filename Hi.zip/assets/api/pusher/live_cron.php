<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../../incfiles/init.php');

$key = $core->antiSpecialChars($db->Real_Escape_String($_GET['key']));

switch ($key) {
	case 1:

		require_once ('live_reward.php');
		require_once ('live_muster.php');
		require_once ('live_phone.php');
		require_once ('live_history.php');
		require_once ('live_bot_history.php');
		require_once ('live_momo_reset.php');

		if ($db->Num_Rows("SELECT * FROM `tb_logs`") > 60)
		{
			$db->Query("DELETE FROM `tb_logs`");
			$db->Query("ALTER TABLE `tb_logs` AUTO_INCREMENT = 1");
		}

		$dataMomo = $db->Query("SELECT `phone` FROM `tb_private_momo` WHERE `is_invisible` = '1'");
		$json_web = array();
		while($row = mysqli_fetch_assoc($dataMomo))  
		{
			$json_web[] = $row;
		}
		echo '{ "MoMoAccount": '.$core->formatExportDatabase(json_encode($json_web, JSON_UNESCAPED_SLASHES)).' }';

		break;
	case 2:

		$phone = $core->antiSpecialChars($db->Real_Escape_String($_GET['phone']));
		$momo_ctrl->refToken();
		$dataMomo = $db->Fetch_Array("SELECT * FROM `tb_private_momo` INNER JOIN `tb_momo` ON `tb_private_momo`.`phone` = `tb_momo`.`phone` WHERE `tb_private_momo`.`phone` = '$phone'");
		$data_new = $momo_ctrl->decodeInfo($dataMomo['info']);
		$response = $momo_ctrl->historyMomo($dataMomo['token']);
		
		if ($dataMomo['count'] > 190)
		{
			$momo_ctrl->resetMomo($phone);
		}
		if ($response['status'] == 'error')
		{
			$db->Query("UPDATE `tb_momo` SET `phone` = '$phone' WHERE `status` = 'relogin'");
		}
		if (!empty($response['data']))
		{
			foreach ($response['data'] as $data)
			{
				$comment = mb_strtoupper($data['comment']);
                $amount = $data['amount'];
				$partnerId = $data['patnerID'];
				$partnerName = $data['partnerName'];
				$tranId = (string)$data['tranId'];
				
				if ($amount < $dataMomo['betMin'] && $amount > $dataMomo['betMax'] && !$momo_history->isTransaction($tranId))
				{
					$db->Query("UPDATE `tb_private_momo` SET `balance` = `balance` + '$amount' WHERE `phone` = '$phone'");
					$momo_history->createTransaction($tranId, $partnerId, $phone, "0", $amount, "0", $comment, "limitBet", "lose");
				}
				
				if (!$db->Num_Rows("SELECT * FROM `tb_game` WHERE `content` = '$comment'") && !$momo_history->isTransaction($tranId))
				{
					$db->Query("UPDATE `tb_private_momo` SET `balance` = `balance` + '$amount' WHERE `phone` = '$phone'");
					$momo_history->createTransaction($tranId, $partnerId, $phone, "0", $amount, "0", $comment, "errorComment", "lose");
				}

				if (!$momo_history->isTransaction($tranId) && $amount >= $dataMomo['betMin'] && $amount <= $dataMomo['betMax'])
		        {
		        	$db->Query("UPDATE `tb_private_momo` SET `balance` = `balance` + '$amount' WHERE `phone` = '$phone'");
		        	$gameType = $db->Fetch_Array("SELECT * FROM `tb_game` WHERE `content` = '$comment'");
					$res = "";
		        	$receive = "";
		        	
					if ($gameType['gameType'] == 'CL_Game' || $gameType['gameType'] == 'CL2_Game' || $gameType['gameType'] == 'TX_Game' || $gameType['gameType'] == '1/3_Game')
		        	{
		        		$number = substr((string)$tranId, -1);
		        		$req = $db->Query("SELECT * FROM `tb_game` WHERE `content` = '$comment'");
		            	while ($row = mysqli_fetch_array($req))
		            	{
		            		$numberTLS = explode(',', $row['numberTLS']);
		            		for ($i = 0; $i <= count($numberTLS); $i++)
				            {
								if ($number == $numberTLS[$i])
								{
									$receive = $amount * $row['amount'];
									$res = $row['content'];
								}
							}
		            	}
		        		if ($res == $comment)
		        		{
		        			$momo_history->createTransaction($tranId, $partnerId, $phone, $gameType['id'], $amount, $receive, $comment, "wait", "win");
		        			$momo_ctrl->updateRealTimeMomo($receive, $phone);
			        		$core->pushNotification($partnerId, $amount);
		            	}
		            	else
		            	{
		            		$momo_history->createTransaction($tranId, $partnerId, $phone, $gameType['id'], $amount, "0", $comment, "done", "lose");
		            	}
		        	}

		        	if ($gameType['gameType'] == 'G3_Game')
		        	{
		        		$number1 = substr((string)$tranId, -2);
		            	$number2 = substr((string)$tranId, -3);
		            	$req = $db->Query("SELECT * FROM `tb_game` WHERE `content` = '$comment'");
		            	while ($row = mysqli_fetch_array($req))
		            	{
		            		$numberTLS = explode(',', $row['numberTLS']);
		            		for ($i = 0; $i < count($numberTLS); $i++)
		            		{
		            			if ($number1 == $numberTLS[$i])
		            			{
		            				$receive = $amount * $row['amount'];
		        					$res = $row['content'];
		            			}
		            			else if ($number2 == $numberTLS[$i])
		            			{
		            				$receive = $amount * $row['amount'];
		        					$res = $row['content'];
		            			}
		            		}
		            	}
		            	if ($res == $comment)
		        		{
		        			$momo_history->createTransaction($tranId, $partnerId, $phone, $gameType['id'], $amount, $receive, $comment, "wait", "win");
		        			$momo_ctrl->updateRealTimeMomo($receive, $phone);
			        		$core->pushNotification($partnerId, $amount);
		            	}
		            	else
		            	{
		            		$momo_history->createTransaction($tranId, $partnerId, $phone, $gameType['id'], $amount, "0", $comment, "done", "lose");
		            	}
		        	}

		        	if ($gameType['gameType'] == 'T3_Game' || $gameType['gameType'] == 'CT_Game')
		        	{
		        		$numbers = str_split((string)substr((string)$tranId, -3));
		            	$total = ($numbers[0] + $numbers[1] + $numbers[2]);
		            	$req = $db->Query("SELECT * FROM `tb_game` WHERE `content` = '".mb_strtoupper($comment)."'");
		            	while ($row = mysqli_fetch_array($req))
		            	{
		            		$numberTLS = explode(',', $row['numberTLS']);
		            		for ($i = 0; $i < count($numberTLS); $i++)
		            		{
			            		if ($total == $numberTLS[$i])
			            		{
			            			$receive = $amount * $row['amount'];
			            			$res = $row['content'];
			            		}
			            	}
		            	}
		            	if ($res == $comment)
		        		{
		        			$momo_history->createTransaction($tranId, $partnerId, $phone, $gameType['id'], $amount, $receive, $comment, "wait", "win");
		        			$momo_ctrl->updateRealTimeMomo($receive, $phone);
			        		$core->pushNotification($partnerId, $amount);
		            	}
		            	else
		            	{
		            		$momo_history->createTransaction($tranId, $partnerId, $phone, $gameType['id'], $amount, "0", $comment, "done", "lose");
		            	}
		        	}

		        	if ($gameType['gameType'] == 'DS_Game')
		        	{
		        		$number = substr((string)$tranId, -1);
		        		$req = $db->Query("SELECT * FROM `tb_game` WHERE `content` = '$comment'");
		            	while ($row = mysqli_fetch_array($req))
		            	{
		            		if ($number == $row['numberTLS'])
		            		{
		            			$receive = $amount * $row['amount'];
		            			$res = $row['content'];
		            		}
		            	}
		        		if ($res == $comment)
		        		{
		        			$momo_history->createTransaction($tranId, $partnerId, $phone, $gameType['id'], $amount, $receive, $comment, "wait", "win");
		        			$momo_ctrl->updateRealTimeMomo($receive, $phone);
			        		$core->pushNotification($partnerId, $amount);
		            	}
		            	else
		            	{
		            		$momo_history->createTransaction($tranId, $partnerId, $phone, $gameType['id'], $amount, "0", $comment, "done", "lose");
		            	}
		        	}
		        }
			}
		}
		echo $phone;

		break;
	default:

		break;
}


ob_flush();
?>