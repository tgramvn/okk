<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../../incfiles/init.php');

$midnight = strtotime("today midnight");
$time = time() - $midnight;

if ($time == 0 || $time > 0 && $time <= 8)
{
	$data = "0";
	for ($i = 1; $i <= 5; $i++)
	{ 
		$tel = $core->cloneNumPhone();
		$data = $data."|".$tel;
	}
	$amount_1 = rand(3000000, 7000000);
	$amount_2 = rand(2000000, 3000000);
	$amount_3 = rand(1000000, 2000000);
	$amount_4 = rand(500000, 1000000);
	$amount_5 = rand(10000, 500000);
	
	$amount_all = "0|".$amount_1."|".$amount_2."|".$amount_3."|".$amount_4."|".$amount_5;

	$db->Query("UPDATE `tb_settings` SET `value` = '$data' WHERE `id` = '38'");
	$db->Query("UPDATE `tb_settings` SET `value` = '$amount_all' WHERE `id` = '39'");

	$req_momo = $db->Query("SELECT * FROM `tb_private_momo`");
	while ($m_data = mysqli_fetch_array($req_momo))
	{
		$day = $db->Num_Rows("SELECT * FROM `tb_momo_reset_logs` WHERE FROM_UNIXTIME(`created_at`, '%Y-%m-%d') = CURDATE() AND `momo_phone` = '".$m_data['phone']."'");
		if (!$day)
		{
			$momo_ctrl->resetAllMomo();
			$db->Query("INSERT INTO `tb_momo_reset_logs` SET `momo_phone` = '".$m_data['phone']."', `created_at` = '".time()."'");
		}
	}
}

ob_flush();
?>
