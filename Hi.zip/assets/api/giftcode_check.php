<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

$giftcode = $core->antiSpecialChars($db->Real_Escape_String($_POST['giftcode']));
$phone = $core->antiSpecialChars($db->Real_Escape_String($_POST['phone']));
if (strlen($phone) < 10 || strlen($phone) > 10)
{
	$arr_total = array(
		'success' => false,
		'message' => 'Số điện thoại nhận giftCode không hợp lệ!'
	);
	die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
}

$row = $db->Fetch_Array("SELECT * FROM `tb_giftcode_cash` WHERE `code` = '$giftcode'");

if ($row)
{
	if ($row['count'] > 1)
	{
		if ($row['state_at'] == 'active' && $row['expired_at'] > time())
		{
			if ($db->Num_Rows("SELECT * FROM `tb_giftcode_use` WHERE `phone` = '$phone' AND `code` = '$giftcode'") > 0)
			{
				$arr_total = array(
					'success' => false,
					'message' => 'Bạn chỉ được dùng GiftCode này một lần!'
				);
				die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
			}
			else
			{
				$dataMomo = $db->Fetch_Array("SELECT * FROM `tb_private_momo` ORDER BY RAND() LIMIT 1");
				$content = $core->formatExportDatabase($core->isHomeSetting('website_name'))." GiftCode ".$giftcode;
				$response = $momo_ctrl->sendMoneyMomo($dataMomo, $row['amount'], $content, $phone);
				if (empty($response) || $response == null || $response["status"] == "error")
				{
					$arr_total = array(
						'success' => false,
						'message' => 'Lỗi hệ thống!'
					);
					die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
				}
				else
				{
					$db->Query("INSERT INTO `tb_momo_transfer_history` SET
						`momo_txn` = '".$response["data"]['tranId']."',
						`momo_phone` = '".$response["data"]['ownerNumber']."',
						`receiver_name` = '".$response["data"]['partnerName']."',
						`receiver_phone` = '".$response["data"]['partnerId']."',
						`amount` = '".$response["data"]['amount']."',
						`content` = '$content',
						`created_at` = '".time()."'");
					$db->Query("INSERT INTO `tb_giftcode_use` SET `phone` = '$phone', `code` = '$giftcode', `created_at` = '".time()."'");
					$db->Query("UPDATE `tb_giftcode_cash` SET `count` = `count` - '1' WHERE `code` = '$giftcode'");
					$arr_total = array(
						'success' => true,
						'message' => 'Sử dụng thành công!'
					);
					die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
				}
			}
		}
		else
		{
			$arr_total = array(
				'success' => false,
				'message' => 'Mã GiftCode này đã hết hạn hoặc hết lượt sử dụng!'
			);
			die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
		}
	}
	else
	{
		if ($row['state_at'] == 'active' && $row['expired_at'] > time())
		{
			$dataMomo = $db->Fetch_Array("SELECT * FROM `tb_private_momo` ORDER BY RAND() LIMIT 1");
			$content = $core->formatExportDatabase($core->isHomeSetting('website_name'))." GiftCode: ".$giftcode;
			$response = $momo_ctrl->sendMoneyMomo($dataMomo, $row['amount'], $content, $phone);
			if (empty($response) || $response == null || $response["status"] == "error")
			{
				$arr_total = array(
					'success' => false,
					'message' => 'Lỗi hệ thống!'
				);
				die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
			}
			else
			{
				$db->Query("INSERT INTO `tb_momo_transfer_history` SET
					`momo_txn` = '".$response["data"]['tranId']."',
					`momo_phone` = '".$response["data"]['ownerNumber']."',
					`receiver_name` = '".$response["data"]['partnerName']."',
					`receiver_phone` = '".$response["data"]['partnerId']."',
					`amount` = '".$response["data"]['amount']."',
					`content` = '$content',
					`created_at` = '".time()."'");
				$db->Query("UPDATE `tb_giftcode_cash` SET `count` = '0', `state_at` = 'dead-active' WHERE `code` = '$giftcode'");
				$arr_total = array(
					'success' => true,
					'message' => 'Sử dụng thành công!'
				);
				die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
			}
		}
		else
		{
			$arr_total = array(
				'success' => false,
				'message' => 'Mã GiftCode này đã hết hạn hoặc hết lượt sử dụng!'
			);
			die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
		}
	}

}
else
{
	$arr_total = array(
		'success' => false,
		'message' => 'Mã GiftCode không tồn tại!'
	);
	die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
}


ob_flush();
?>
