<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

$gameType = $core->antiSpecialChars($db->Real_Escape_String($_POST['gameType']));

$req = $db->Query("SELECT * FROM `tb_game` WHERE `gameType` = '$gameType'");
$arr_res = array();
while ($row = mysqli_fetch_assoc($req))
{
	$numberTLS = explode(',', $row['numberTLS']);
	$arr_res[] = array(
		'gameType' => $row['gameType'],
		'content' => $row['content'],
		'numberTLS' => $numberTLS,
		'amount' => $row['amount'],
	);
}

$arr_total = array(
	'success' => true,
	'message' => 'Lấy thành công!',
	'data' => $arr_res
);

header('Content-Type: application/json');

echo stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));

ob_flush();
?>