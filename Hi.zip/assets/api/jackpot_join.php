<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
header('Content-Type: application/json');


$phone = $core->antiSpecialChars($db->Real_Escape_String($_POST['phone']));

if (strlen($phone) < 10 || strlen($phone) > 10)
{
	$arr_total = array(
		'success' => false,
		'message' => 'Số điện thoại đăng ký không hợp lệ!'
	);
	die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));
}

$query = "SELECT * FROM `tb_jackpot_player` WHERE FROM_UNIXTIME(`created_at`, '%Y-%m-%d') = CURDATE() AND `phone` = '$phone' ORDER BY `id` DESC";

switch ($act) {
	case 'join':

		$db->Query("INSERT INTO `tb_jackpot_player` SET
			`phone` = '$phone',
			`created_at` = '".time()."'");

		$arr_total = array(
			'success' => true,
			'message' => 'Tham gia thành công!'
		);
		
		die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));

		break;
	case 'out':

		$db->Query("DELETE FROM `tb_jackpot_player` WHERE `phone` = '$phone' AND FROM_UNIXTIME(`created_at`, '%Y-%m-%d') = CURDATE()");
		$arr_total = array(
			'success' => true,
			'message' => 'Hủy tham gia thành công!'
		);
		die(stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)));

		break;
	
	default:

		break;
}

ob_flush();
?>