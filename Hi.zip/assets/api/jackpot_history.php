<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
header('Content-Type: application/json');

$row = $db->Fetch_Array("SELECT * FROM `tb_jackpot`");

$arr_res = array();
while ($row = mysqli_fetch_array($req))
{
	$arr_res[] = array(
		'phone' => $row['phone'],
		'amount' => (int)$row['amount'],
		'time' => $row['created_at'],
	);
}

$arr_total = array(
	'success' => true,
	'message' => 'Lấy thành công!',
	'data' => $arr_res
);

echo stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));

ob_flush();
?>