<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
header('Content-Type: application/json');

$arr_res = array();
$req = $db->Query("SELECT * FROM `tb_momo` WHERE `status` = 'active'");
while ($row = mysqli_fetch_assoc($req))
{
    if ($db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `phone` = '".$row['phone']."'")['is_invisible'] == '1')
    {
    	$arr_res[] = array(
            "id" => $row['id'],
            "name" => mb_strtoupper($core->Unicode_VNI($row['name'])),
            "phone" => $row['phone'],
            "bonus" => 0,
            "limitDay" => (int)$row['limitDay'],
            "limitMonth" => (int)$row['limitMonth'],
            "number" => (int)$row['number'],
            "betMin" => (int)$row['betMin'],
            "betMax" => (int)$row['betMax'],
            "amountDay" => (int)$row['amountDay'],
            "amountMonth" => (int)$row['amountMonth'],
            "count" => (int)$row['count'],
            "status" => $row['status']
    	);
    }
}

$arr_total = array(
	'success' => true,
	'message' => 'Lấy thành công!',
	'data' => $arr_res
);

echo stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));

ob_flush();
?>