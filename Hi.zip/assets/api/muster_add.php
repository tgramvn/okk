<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

$phone = $core->antiSpecialChars($db->Real_Escape_String($_POST['phone']));
$row = $db->Fetch_Array("SELECT * FROM `tb_muster` WHERE `state_at` = 'active' ORDER BY `id` DESC LIMIT 1");

if (date("H", time()) >= (int)$core->isHomeSetting('muster_start') & date("H", time()) <= (int)$core->isHomeSetting('muster_end'))
{
	if (!$db->Num_Rows("SELECT * FROM `tb_muster_player` WHERE `muster_id` = '".$row['code']."' AND `phone` = '$phone'"))
	{
		$db->Query("INSERT INTO `tb_muster_player` SET `muster_id` = '".$row['code']."', `phone` = '$phone', `created_at` = '".time()."'");
		$arr_total = array(
			'success' => true,
			'message' => 'Bạn đã điểm thành công!'
		);
		echo stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
	}
	else
	{
		$arr_total = array(
			'success' => false,
			'message' => 'Bạn đã điểm danh rồi!'
		);
		echo stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
	}
}
else
{
	$arr_total = array(
		'success' => false,
		'message' => 'Điểm danh chỉ hoạt động từ '.$core->isHomeSetting('muster_start').'h - '.$core->isHomeSetting('muster_end').'h!'
	);
	echo stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}

ob_flush();
?>
