<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
header('Content-Type: application/json');

if (date("H", time()) >= (int)$core->isHomeSetting('muster_start') && date("H", time()) <= (int)$core->isHomeSetting('muster_end'))
{
	$row = $db->Fetch_Array("SELECT * FROM `tb_muster` WHERE `state_at` = 'active' ORDER BY `id` DESC LIMIT 1");
	$count = $db->Num_Rows("SELECT * FROM `tb_muster_player` WHERE `muster_id` = '".$row['code']."'");
	$res = $db->Query("SELECT * FROM `tb_muster_player` WHERE `is_win` = '1' ORDER BY `id` DESC LIMIT 5");
	$time_check = (int)$row['created_at'] + (int)$core->isHomeSetting('muster_time');
	$muster_data = array();
	while ($player = mysqli_fetch_array($res))
	{
		$muster = $db->Fetch_Array("SELECT * FROM `tb_muster` WHERE `code` = '".$player['muster_id']."'");
		$muster_data[] = array(
			'code' => (int)$player['muster_id'],
			'count' => (int)$count,
			'phone' => $core->maskNumPhone($player['phone']),
			'amount' => (int)$muster['bonus'],
			'time' => $player['created_at']
		);
	}
	$export_data = array(
		'success' => true,
		'message' => 'Lấy thành công!',
		'data' => $muster_data
	);

	echo stripslashes(json_encode($export_data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}
else
{
	$row = $db->Fetch_Array("SELECT * FROM `tb_muster` ORDER BY `id` DESC LIMIT 1");
	$count = $db->Num_Rows("SELECT * FROM `tb_muster_player` WHERE `muster_id` = '".$row['code']."'");
	
	$res = $db->Query("SELECT * FROM `tb_muster_player` WHERE `is_win` = '1' ORDER BY `id` DESC LIMIT 5");
	$muster_data = array();
	while ($player = mysqli_fetch_array($res))
	{
		$muster = $db->Fetch_Array("SELECT * FROM `tb_muster` WHERE `code` = '".$player['muster_id']."'");
		$muster_data[] = array(
			'code' => (int)$player['muster_id'],
			'count' => (int)$count,
			'phone' => $core->maskNumPhone($player['phone']),
			'amount' => (int)$muster['bonus'],
			'time' => 0
		);
	}
	$export_data = array(
		'success' => true,
		'message' => 'Lấy thành công!',
		'data' => $muster_data
	);
	echo stripslashes(json_encode($export_data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}

ob_flush();
?>