<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
header('Content-Type: application/json');

$transId = $core->antiSpecialChars($db->Real_Escape_String($_POST['transId']));

if ($row = $db->Fetch_Array("SELECT * FROM `tb_history` WHERE `momo_txn` = '$transId'"))
{
	$game = $db->Fetch_Array("SELECT * FROM `tb_game` WHERE `id` = '".$row['gameId']."'");
	$arr_res = array(
		'transId' => $row['momo_txn'],
		'phone' => substr($row['phone'], 0, 6)."****",
		'amount' => $row['money'],
		'bonus' => $row['bonus'],
		'gameName' => $game['gameName'],
		'comment' => $row['content'],
		'status' => $row['pay_at'],
		'result' => $row['stated_at'],
		'time' => date("Y-m-d H:i:s", $row['created_at'])
	);

	$arr_total = array(
		'success' => true,
		'message' => 'Lấy thành công!',
		'data' => $arr_res
	);
	echo stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}
else
{
	echo '{"success":false,"message":"Không tìm thấy mã giao dịch này!","data":[]}';
}



ob_flush();
?>