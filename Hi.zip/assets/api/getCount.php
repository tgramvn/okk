<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');
header('Content-Type: application/json');

$phone = $core->antiSpecialChars($db->Real_Escape_String($_POST['phone']));

if ($db->Fetch_Array("SELECT * FROM `tb_history` WHERE `phone` = '$phone'"))
{
	$data = $db->Fetch_Array("SELECT `phone`, SUM(`bonus`), `created_at`, `stated_at` FROM `tb_history` WHERE FROM_UNIXTIME(`created_at`, '%Y-%m-%d') = CURDATE() AND `stated_at` = 'win' AND `phone` = '$phone' GROUP BY `phone`");

	$result = array(
		'success' => true,
		'message' => 'Lấy thành công!',
		'count' => $data['SUM(`bonus`)']
	);
	echo stripslashes(json_encode($result, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}
else
{
	echo '{"success":false,"message":"Không tìm thấy số điện thoại này!","data":[]}';
}



ob_flush();
?>