<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('../../incfiles/init.php');

$req = $db->Query("SELECT * FROM `tb_history` WHERE `stated_at` = 'win' ORDER BY `id` DESC LIMIT 10");
$arr_res = array();
while ($row = mysqli_fetch_array($req))
{
	$game = $db->Fetch_Array("SELECT * FROM `tb_game` WHERE `id` = '".$row['gameId']."'");
	$arr_res[] = array(
		'phone' => substr($row['phone_player'], 0, 6)."****",
		'money' => (int)$row['money'],
		'bonus' => (int)$row['bonus'],
		'gameName' => $game['gameName'],
		'content' => $row['content'],
		'result' => $row['stated_at'],
		'time' => date("Y-m-d H:i:s", $row['created_at'])
	);
}

$arr_total = array(
	'success' => true,
	'message' => 'Lấy thành công!',
	'data' => $arr_res
);

header('Content-Type: application/json');

echo stripslashes(json_encode($arr_total, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));

ob_flush();
?>