-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th12 19, 2022 lúc 06:43 AM
-- Phiên bản máy phục vụ: 10.5.18-MariaDB-cll-lve
-- Phiên bản PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `momosme1_null`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_clone_phone`
--

CREATE TABLE `tb_clone_phone` (
  `id` int(100) UNSIGNED NOT NULL,
  `telco` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tb_clone_phone`
--

INSERT INTO `tb_clone_phone` (`id`, `telco`, `code`) VALUES
(1, 'VIETTEL', '032,033,034,035,036,037,038,037,038,039,086,096,097,098'),
(2, 'MOBIFONE', '070,079,077,076,078,089,090,093'),
(3, 'VINAPHONE', '083,084,085,081,082,088,091,094'),
(4, 'VIETNAMOBILE', '056,058,092');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_devices`
--

CREATE TABLE `tb_devices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `device` varchar(255) NOT NULL,
  `hardware` varchar(255) NOT NULL,
  `facture` varchar(255) NOT NULL,
  `MODELID` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tb_devices`
--

INSERT INTO `tb_devices` (`id`, `device`, `hardware`, `facture`, `MODELID`, `created_at`, `updated_at`) VALUES
(1, 'SM-G532F', 'mt6735', 'samsung', 'samsung sm-g532gmt6735r58j8671gsw', '2022-06-23 11:07:55', '2022-06-23 11:07:56'),
(3, 'SM-A102U', 'a10e', 'Samsung', 'Samsung SM-A102U', '2022-06-23 11:07:57', '2022-06-23 11:07:57'),
(4, 'SM-A305FN', 'a30', 'Samsung', 'Samsung SM-A305FN', '2022-06-23 11:07:58', '2022-06-23 11:07:59'),
(5, 'HTC One X9 dual sim', 'htc_e56ml_dtul', 'HTC', 'HTC One X9 dual sim', '2022-06-23 11:08:00', '2022-06-23 11:08:01'),
(6, 'HTC 7060', 'cp5dug', 'HTC', 'HTC HTC_7060', '2022-06-23 11:08:02', '2022-06-23 11:08:00'),
(7, 'HTC D10w', 'htc_a56dj_pro_dtwl', 'HTC', 'HTC htc_a56dj_pro_dtwl', '2022-06-23 11:08:04', '2022-06-23 11:08:03'),
(8, 'Oppo realme X Lite', 'RMX1851CN', 'Oppo', 'Oppo RMX1851', '2022-06-23 11:08:04', '2022-06-23 11:08:05'),
(9, 'MI 9', 'equuleus', 'Xiaomi', 'Xiaomi equuleus', '2022-06-23 11:08:06', '2022-06-23 11:08:06');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_game`
--

CREATE TABLE `tb_game` (
  `id` int(100) UNSIGNED NOT NULL,
  `gameName` varchar(255) NOT NULL,
  `gameType` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `content` varchar(255) NOT NULL,
  `numberTLS` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `enable` varchar(255) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tb_game`
--

INSERT INTO `tb_game` (`id`, `gameName`, `gameType`, `description`, `content`, `numberTLS`, `amount`, `enable`) VALUES
(1, 'Chẳn Lẻ', 'CL_Game', 'Với nội dung : <b>C</b> hoặc <b>L</b> (nếu đuôi mã giao dịch có các số sau)', 'L', '1,3,5,7', '2.4', '1'),
(2, 'Chẳn Lẻ', 'CL_Game', 'Với nội dung : <b>C</b> hoặc <b>L</b> (nếu đuôi mã giao dịch có các số sau)', 'C', '2,4,6,8', '2.4', '1'),
(3, 'Tài Xỉu', 'TX_Game', 'Với nội dung : <b>T</b> hoặc <b>X</b> (nếu đuôi mã giao dịch có các số sau)', 'X', '1,2,3,4', '2.4', '1'),
(4, 'Tài Xỉu', 'TX_Game', 'Với nội dung : <b>T</b> hoặc <b>X</b> (nếu đuôi mã giao dịch có các số sau)', 'T', '5,6,7,8', '2.4', '1'),
(5, 'Chẳn Lẻ 2', 'CL2_Game', 'Với nội dung : <b>C2</b> hoặc <b>L2</b> hoặc <b>T2</b> hoặc <b>X2</b> (nếu đuôi mã giao dịch có các số sau)', 'L2', '1,3,5,7,9', '1.95', '1'),
(6, 'Chẳn Lẻ 2', 'CL2_Game', 'Với nội dung : <b>C2</b> hoặc <b>L2</b> hoặc <b>T2</b> hoặc <b>X2</b> (nếu đuôi mã giao dịch có các số sau)', 'C2', '0,2,4,6,8', '1.95', '1'),
(7, 'Chẳn Lẻ 2', 'CL2_Game', 'Với nội dung : <b>C2</b> hoặc <b>L2</b> hoặc <b>T2</b> hoặc <b>X2</b> (nếu đuôi mã giao dịch có các số sau)', 'X2', '0,1,2,3,4', '1.95', '1'),
(8, 'Chẳn Lẻ 2', 'CL2_Game', 'Với nội dung : <b>C2</b> hoặc <b>L2</b> hoặc <b>T2</b> hoặc <b>X2</b> (nếu đuôi mã giao dịch có các số sau)', 'T2', '5,6,7,8,9', '1.95', '1'),
(9, 'Gấp 3', 'G3_Game', 'Với nội dung : <b>G3</b> (nếu đuôi mã giao dịch có các số sau)', 'G3', '02,13,17,19,21,29,35,37,47,49,51,54,57,63,64,74,83,91,95,96', '3', '1'),
(10, 'Gấp 3', 'G3_Game', 'Với nội dung : <b>G3</b> (nếu đuôi mã giao dịch có các số sau)', 'G3', '66,99', '4', '1'),
(11, 'Gấp 3', 'G3_Game', 'Với nội dung : <b>G3</b> (nếu đuôi mã giao dịch có các số sau)', 'G3', '123,234,456,678,789', '5', '1'),
(12, 'Tổng 3 Số', 'T3_Game', 'Với nội dung : <b>S</b> (nếu tổng 3 số cuối của mã giao dịch có các số sau)', 'S', '7,17,27', '2', '1'),
(13, 'Tổng 3 Số', 'T3_Game', 'Với nội dung : <b>S</b> (nếu tổng 3 số cuối của mã giao dịch có các số sau)', 'S', '8,18', '3', '1'),
(14, 'Tổng 3 Số', 'T3_Game', 'Với nội dung : <b>S</b> (nếu tổng 3 số cuối của mã giao dịch có các số sau)', 'S', '9,19', '3.5', '1'),
(15, '1 Phần 3', '1/3_Game', 'Với nội dung : <b>N1</b> hoặc <b>N2</b> hoặc <b>N3</b> (nếu đuôi mã giao dịch có các số sau)', 'N1', '1,2,3', '3', '1'),
(16, '1 Phần 3', '1/3_Game', 'Với nội dung : <b>N1</b> hoặc <b>N2</b> hoặc <b>N3</b> (nếu đuôi mã giao dịch có các số sau)', 'N2', '4,5,6', '3', '1'),
(17, '1 Phần 3', '1/3_Game', 'Với nội dung : <b>N1</b> hoặc <b>N2</b> hoặc <b>N3</b> (nếu đuôi mã giao dịch có các số sau)', 'N3', '7,8,9', '3', '1'),
(18, 'Đoán Số', 'DS_Game', 'Nếu mã giao dịch có số cuối trùng với 1 trong 3 số trên, bạn sẽ chiến thắng', 'D0', '0', '7', '1'),
(19, 'Đoán Số', 'DS_Game', 'Nếu mã giao dịch có số cuối trùng với 1 trong 3 số trên, bạn sẽ chiến thắng', 'D1', '1', '7', '1'),
(20, 'Đoán Số', 'DS_Game', 'Nếu mã giao dịch có số cuối trùng với 1 trong 3 số trên, bạn sẽ chiến thắng', 'D2', '2', '7', '1'),
(21, 'Đoán Số', 'DS_Game', 'Nếu mã giao dịch có số cuối trùng với 1 trong 3 số trên, bạn sẽ chiến thắng', 'D3', '3', '7', '1'),
(22, 'Đoán Số', 'DS_Game', 'Nếu mã giao dịch có số cuối trùng với 1 trong 3 số trên, bạn sẽ chiến thắng', 'D4', '4', '7', '1'),
(23, 'Đoán Số', 'DS_Game', 'Nếu mã giao dịch có số cuối trùng với 1 trong 3 số trên, bạn sẽ chiến thắng', 'D5', '5', '7', '1'),
(24, 'Đoán Số', 'DS_Game', 'Nếu mã giao dịch có số cuối trùng với 1 trong 3 số trên, bạn sẽ chiến thắng', 'D6', '6', '7', '1'),
(25, 'Đoán Số', 'DS_Game', 'Nếu mã giao dịch có số cuối trùng với 1 trong 3 số trên, bạn sẽ chiến thắng', 'D7', '7', '7', '1'),
(26, 'Đoán Số', 'DS_Game', 'Nếu mã giao dịch có số cuối trùng với 1 trong 3 số trên, bạn sẽ chiến thắng', 'D8', '8', '7', '1'),
(27, 'Đoán Số', 'DS_Game', 'Nếu mã giao dịch có số cuối trùng với 1 trong 3 số trên, bạn sẽ chiến thắng', 'D9', '9', '7', '1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_giftcode`
--

CREATE TABLE `tb_giftcode` (
  `id` int(100) UNSIGNED NOT NULL,
  `code` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `state_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_giftcode_cash`
--

CREATE TABLE `tb_giftcode_cash` (
  `id` int(100) UNSIGNED NOT NULL,
  `code` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `count` varchar(255) NOT NULL,
  `state_at` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `expired_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_giftcode_use`
--

CREATE TABLE `tb_giftcode_use` (
  `id` int(100) UNSIGNED NOT NULL,
  `phone` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_history`
--

CREATE TABLE `tb_history` (
  `id` int(10) UNSIGNED NOT NULL,
  `is_bot` varchar(255) NOT NULL DEFAULT '0',
  `momo_txn` varchar(255) NOT NULL,
  `phone_player` varchar(255) NOT NULL,
  `phone_recv` varchar(255) NOT NULL,
  `gameId` varchar(255) NOT NULL,
  `money` varchar(255) NOT NULL,
  `bonus` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `pay_at` varchar(255) NOT NULL,
  `stated_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_jackpot_player`
--

CREATE TABLE `tb_jackpot_player` (
  `id` int(100) UNSIGNED NOT NULL,
  `jackpot_id` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_jackpot_session`
--

CREATE TABLE `tb_jackpot_session` (
  `id` int(100) UNSIGNED NOT NULL,
  `phone` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_logs`
--

CREATE TABLE `tb_logs` (
  `id` int(100) UNSIGNED NOT NULL,
  `action` text NOT NULL,
  `content` text NOT NULL,
  `created_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_momo`
--

CREATE TABLE `tb_momo` (
  `id` int(100) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `bonus` varchar(255) NOT NULL,
  `limitDay` varchar(255) NOT NULL,
  `limitMonth` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `betMin` varchar(255) NOT NULL,
  `betMax` varchar(255) NOT NULL,
  `amountDay` varchar(255) NOT NULL,
  `amountMonth` varchar(255) NOT NULL,
  `count` varchar(255) NOT NULL,
  `cron_rand_time` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_momo_reset_logs`
--

CREATE TABLE `tb_momo_reset_logs` (
  `id` int(100) UNSIGNED NOT NULL,
  `momo_phone` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_momo_transfer_history`
--

CREATE TABLE `tb_momo_transfer_history` (
  `id` int(100) UNSIGNED NOT NULL,
  `momo_txn` varchar(255) NOT NULL,
  `momo_phone` varchar(255) NOT NULL,
  `receiver_phone` varchar(255) NOT NULL,
  `receiver_name` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_muster`
--

CREATE TABLE `tb_muster` (
  `id` int(100) UNSIGNED NOT NULL,
  `code` varchar(255) NOT NULL,
  `bonus` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `state_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_muster_player`
--

CREATE TABLE `tb_muster_player` (
  `id` int(100) UNSIGNED NOT NULL,
  `muster_id` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `is_win` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_private_momo`
--

CREATE TABLE `tb_private_momo` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `token` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL DEFAULT '0',
  `info` longtext NOT NULL,
  `status` int(11) NOT NULL,
  `time_login` varchar(255) NOT NULL,
  `try` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL,
  `is_invisible` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_pusher`
--

CREATE TABLE `tb_pusher` (
  `id` int(100) UNSIGNED NOT NULL,
  `pusher_app_id` varchar(255) NOT NULL,
  `pusher_cluster` varchar(255) NOT NULL,
  `pusher_key` varchar(255) NOT NULL,
  `pusher_secret` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_settings`
--

CREATE TABLE `tb_settings` (
  `id` int(100) UNSIGNED NOT NULL,
  `name` text NOT NULL,
  `value` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tb_settings`
--

INSERT INTO `tb_settings` (`id`, `name`, `value`) VALUES
(1, 'favicon', '/assets/images/logo.png'),
(2, 'description', 'Chẵn Lẻ MoMo - Mini game giải trí chẵn lẻ Momo uy tín và hệ thống thanh toán tự động trong 30s, kiếm Tiền Nhanh Chóng chỉ trong 1 nốt nhạc.'),
(19, 'refund', 'Yes'),
(3, 'website_url', 'https://'),
(4, 'website_name', ''),
(5, 'keywords', 'MOMO TU DONG, CTLXUK, CLMMBUZZ, CHẴN LẺ MOMO, CHAN LE MOMO, CLTX, CLMM, TÀI XỈU MOMO, chẵn lẻ momo, clmm, chan le momo, Clmm, Chẵn lẻ momo, Chan le momo, clmmbuzz, Clmmbuzz, cltx, Cltx, clmm me, clmm 10k, chẵn lẻ momo 10k, momo chan le, clmm 247, clmm ai, clmm 5k, clmm365, clmm247, clmm momo'),
(7, 'nofication_ex', '<h5 style=\"color:darkcyan;text-align:center\">	<b><br><br>CHÀO MỪNG BẠN ĐẾN VỚI HỆ THỐNG GAME MOMO UY TÍN SỐ 1 VN </b></h5><h6 style=\"color: #333;text-align:center\">	<div>Kết quả dựa vào Mã giao dịch ví MOMO</div>	<div>Trả thưởng nhanh - Minh bạch - Xanh chín</div></h6><div>	<b class=\"text-danger\">⚠️ Một số lưu ý của chúng tôi, người chơi mới vui lòng đọc qua trước khi chơi nhé!</b></div><div class=\"alert alert-warning\">Hiện nay khi thành viên mới tham gia nhóm chat <b>Telegram</b> hoặc <b>Zalo</b> sẽ có một số đối tượng lừa đảo là admin hỗ trợ lỗi + cho số chơi không hiện trên web. Mọi trường hợp đó đều là lừa đảo. Chúng tôi sẽ chỉ hỗ trợ những đơn chuyển vào số hiện trên website. Hãy cảnh giác và là người chơi thông thái! </div><ol>	<li>Mỗi số MOMO trên web nhận tối đa 100M/tháng. Vì vậy, <b>Vui lòng F5 để reload web hoặc đợi web tự làm mới danh sách số mỗi lần chơi, phòng trường hợp đổi số điện thoại khi hết hạn mức giao dịch.</b>Chơi nhầm số tắt vui lòng báo admin trong vòng 24h vẫn trả thưởng bình thường. </li>	<li>Nếu bạn chiến thắng mà tiền thưởng chưa về,hãy sử dụng chức năng \"TRA CỨU GIAO DỊCH\". Trường hợp tra mã giao dịch báo <b style=\"color:#1c05bb;\">\" TẠM GIỮ \" </b>hoặc <b style=\"color:#1c05bb;\">\" KHÔNG TÌM THẤY KẾT QUẢ \" </b>vui lòng liên hệ admin ở phần HỖ TRỢ để được xử lý nhanh nhất. </li>	<li><strong>Thời gian tính điều kiện để nhận mã khuyến mại được tính từ lần đầu nhập mã. </strong></li>	<li>Chuyển nhầm hạn mức, sai nội dung sẽ không được hoàn. <br>CLMM, CHẴN LẺ MOMO, CHAN LE MOMO, CHANLEMOMO, CLTX, TRUMMOMO</li></ol>'),
(8, 'support_telegram_group', ''),
(9, 'support_zalo', ''),
(10, 'support_talk_index', ''),
(11, 'title', 'Chẵn lẻ MoMo - Hệ Thống Game Giải Trí CLMM Uy Tín, Tự Động'),
(12, 'support_telegram_account', ''),
(13, 'muster_bonus', '150000'),
(14, 'cron_rand_time', '1669623060'),
(20, 'refund_win', '100'),
(21, 'refund_lose', '0'),
(22, 'refund_maximum', '0'),
(23, 'muster_start', '7'),
(24, 'muster_end', '23'),
(25, 'muster_time', '900'),
(26, 'muster_ex', '- Mỗi phiên quà các bạn có 15 phút để điểm danh. <br>- Số điện thoại điểm danh phải chơi mini game trên hệ thống ít nhất 1 lần trong ngày. Không giới hạn số lần điểm danh trong ngày. <br>- Khi hết thời gian, người may mắn sẽ nhận được số tiền của phiên đó. <br>- Game <b>Điểm danh miễn phí</b> chỉ hoạt động từ <b>7h - 24h<br>CLMM, CHẴN LẺ MOMO, CHANLEMOMO, TRUMMOMO</b>'),
(27, 'og:image', '/assets/images/Vi-MOMO.png'),
(28, 'jackpot', 'Yes'),
(29, 'jackpot_amount', '9999'),
(30, 'jackpot_code', '111 - 222 - 333 - 444 - 555 - 666 - 777 - 888 - 999'),
(31, 'jackpot_amount_minus', '1111'),
(32, 'nofication', 'On'),
(33, 'alert', '<div>Nội dung chuyển khoản không phân biệt in hoa, thường. Nội dung phải đúng với quy định của trò chơi.</div><div><b>Kiểm tra chính xác số điện thoại mà bạn sắp chuyển có tình trạng là <span class=\"badge badge-success\">Hoạt động</span> không, nếu tình trạng là <span class=\"badge badge-danger\">Bảo trì</span> vui lòng chuyển vào số khác.</b></div><div>Chuyển nhầm hạn mức, sai nội dung sẽ không được hoàn.<br>Số&nbsp;<span class=\"badge badge-danger\" style=\"background-color: rgb(252, 243, 207); font-size: 15px;\">Bảo trì</span>&nbsp;admin sẽ xem xét lại, nếu thắng vẫn sẽ được nhận thưởng.<br></div><div>Nếu kết quả <b>Thắng</b>, bạn sẽ nhận được tiền thưởng tự động trong vòng <b>30s - 1 phút</b>. Số tiền thưởng sẽ được chuyển vào ví Momo của bạn.<br>CLMM, CHẴN LẺ MOMO, CHAN LE MOMO, CHANLEMOMO, TRUMMOMO</div>'),
(34, 'support_link', ''),
(35, 'top_day', '0||||||'),
(36, 'top_day_virtual', 'On'),
(37, 'top_day_virtual_amount', '0|50000|40000|30000|20000|10000'),
(38, 'top_day_virtual_phone', '0|0372435324|0789076210|0813515093|0327645237|0385737843'),
(39, 'top_day_virtual_win', '0|6188409|2974376|1879914|593736|439068'),
(40, 'top_day_player_amount', '0|1000000|12000000|29000000|49000000'),
(41, 'top_day_player_bonus', '0|20000|50000|100000|150000'),
(42, 'bot_autogame', 'On'),
(43, 'bot_automuster', 'On'),
(44, 'muster_money_start', '1000'),
(45, 'muster_money_end', '8000');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_task`
--

CREATE TABLE `tb_task` (
  `id` int(100) UNSIGNED NOT NULL,
  `momo_txn` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_users`
--

CREATE TABLE `tb_users` (
  `id` int(100) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `last_access` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tb_users`
--

INSERT INTO `tb_users` (`id`, `username`, `password`, `full_name`, `balance`, `gender`, `ip_address`, `last_access`) VALUES
(1, 'Admin', '14e1b600b1fd579f47433b88e8d85291', 'Full Source', '0', 'MALE', '', '1671431384');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `tb_clone_phone`
--
ALTER TABLE `tb_clone_phone`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_devices`
--
ALTER TABLE `tb_devices`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_game`
--
ALTER TABLE `tb_game`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_giftcode`
--
ALTER TABLE `tb_giftcode`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_giftcode_cash`
--
ALTER TABLE `tb_giftcode_cash`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_giftcode_use`
--
ALTER TABLE `tb_giftcode_use`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_history`
--
ALTER TABLE `tb_history`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_jackpot_player`
--
ALTER TABLE `tb_jackpot_player`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_jackpot_session`
--
ALTER TABLE `tb_jackpot_session`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_logs`
--
ALTER TABLE `tb_logs`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_momo`
--
ALTER TABLE `tb_momo`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_momo_reset_logs`
--
ALTER TABLE `tb_momo_reset_logs`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_momo_transfer_history`
--
ALTER TABLE `tb_momo_transfer_history`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_muster`
--
ALTER TABLE `tb_muster`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_muster_player`
--
ALTER TABLE `tb_muster_player`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_private_momo`
--
ALTER TABLE `tb_private_momo`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_pusher`
--
ALTER TABLE `tb_pusher`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_settings`
--
ALTER TABLE `tb_settings`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_task`
--
ALTER TABLE `tb_task`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `tb_clone_phone`
--
ALTER TABLE `tb_clone_phone`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `tb_devices`
--
ALTER TABLE `tb_devices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT cho bảng `tb_game`
--
ALTER TABLE `tb_game`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT cho bảng `tb_giftcode`
--
ALTER TABLE `tb_giftcode`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `tb_giftcode_cash`
--
ALTER TABLE `tb_giftcode_cash`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `tb_giftcode_use`
--
ALTER TABLE `tb_giftcode_use`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_history`
--
ALTER TABLE `tb_history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_jackpot_player`
--
ALTER TABLE `tb_jackpot_player`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_jackpot_session`
--
ALTER TABLE `tb_jackpot_session`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_logs`
--
ALTER TABLE `tb_logs`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_momo`
--
ALTER TABLE `tb_momo`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_momo_reset_logs`
--
ALTER TABLE `tb_momo_reset_logs`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_momo_transfer_history`
--
ALTER TABLE `tb_momo_transfer_history`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_muster`
--
ALTER TABLE `tb_muster`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_muster_player`
--
ALTER TABLE `tb_muster_player`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_private_momo`
--
ALTER TABLE `tb_private_momo`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_pusher`
--
ALTER TABLE `tb_pusher`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_settings`
--
ALTER TABLE `tb_settings`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT cho bảng `tb_task`
--
ALTER TABLE `tb_task`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
