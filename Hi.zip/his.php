<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once ('incfiles/init.php');
header('Content-Type: application/json');


$dataMomo = $db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `phone` = '0562849409'");

//echo json_encode($momo_ctrl->historyMomo($dataMo

echo json_encode($momo_ctrl->historyMomoV2($dataMomo['token']), JSON_PRETTY_PRINT);

?>
