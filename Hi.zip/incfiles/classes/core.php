<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once (realpath($_SERVER["DOCUMENT_ROOT"]) .'/vendor/autoload.php');

use Carbon\Carbon;

$act = isset($_REQUEST['act']) ? trim($_REQUEST['act']) : '';

class Core
{
	protected $db;
	
	public function __construct($conn)
	{
		$this->db = $conn;
	}

	public function antiSpecialChars ($string) 
	{
		return htmlspecialchars(htmlentities(strip_tags($string), ENT_QUOTES, 'UTF-8'));
	}
	
	public function formatExportDatabase($database = null)
	{
		if ($database == null)
		{
			return false;
			exit();
		}
		return html_entity_decode($database);
	}

	public function isHomeSetting($name = null)
	{
		$row = $this->db->Fetch_Array("SELECT * FROM `tb_settings` WHERE `name` = '$name'");
		return $row['value'];
	}

	public function quickRandom($length = 16)
	{
	    $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

	    return substr(str_shuffle(str_repeat($pool, 5)), 0, $length);
	}

	public function addArray($main_arr = null, $merge_arr = null)
	{
		return array_merge((array)$main_arr, (array)$merge_arr);
	}

	public function ajaxReturnMsg($statusId = null, $message = null)
	{
		$arr = array(
			'status' => $statusId,
			'message' => $message
		);
		return json_encode($arr);
	}

	public function Unicode_VNI($str = null)
	{
		$str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $str);
		$str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
		$str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
		$str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
		$str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
		$str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
		$str = preg_replace("/(đ)/", 'd', $str);
		$str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $str);
		$str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $str);
		$str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $str);
		$str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $str);
		$str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $str);
		$str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $str);
		$str = preg_replace("/(Đ)/", 'D', $str);
		return $str;
	}

	function createCode()
	{
		$code = rand(000000, 100000);
		while($this->db->Num_Rows("SELECT * FROM `tb_muster` WHERE `code` = '$code'"))
		{
			$rand = rand(000000, 100000);
			if (!$this->db->Num_Rows("SELECT * FROM `tb_muster` WHERE `code` = '$code'"))
			{
				$code = $rand;
				break;
			}
		}
		return $code;
	}

	public function pusher($channel = null, $data_array = null)
	{
		$pushdata = $this->db->Fetch_Array("SELECT * FROM `tb_pusher` ORDER BY RAND() LIMIT 1");
		$options = array(
			'cluster' => $pushdata['pusher_cluster'],
			'useTLS' => true
		);
		$pusher = new Pusher\Pusher(
			$pushdata['pusher_key'],
			$pushdata['pusher_secret'],
			(int)$pushdata['pusher_app_id'],
			$options
		);
		return $pusher->trigger('appPusher', $channel, $data_array);
	}

	public function pushNotification($phone = null, $amount = null)
	{
		$pushdata = $this->db->Fetch_Array("SELECT * FROM `tb_pusher` ORDER BY RAND() LIMIT 1");
		$options = array(
			'cluster' => $pushdata['pusher_cluster'],
			'useTLS' => true
		);
		$pusher = new Pusher\Pusher(
			$pushdata['pusher_key'],
			$pushdata['pusher_secret'],
			(int)$pushdata['pusher_app_id'],
			$options
		);

		$arr_res = array(
			'phone' => substr($phone, 0, 6)."****",
			'amount' => $amount
		);
		return $pusher->trigger('appPusher', 'notiWin', $arr_res);
	}

	public function cloneNumPhone()
	{
		$telco = array();
		$req = $this->db->Query("SELECT * FROM `tb_clone_phone`");
		while ($row = mysqli_fetch_array($req))
		{
			$code = explode(',', $row['code']);
			for ($i = 0; $i < count($code); $i++)
			{
				$telco[] = $code[$i];
			}
		}
		$rand = array_rand($telco);
		$tel = $telco[$rand].rand(1111119, 9999999);

		return $tel;
	}

	public function maskNumPhone($number = null)
	{
		return substr($number, 0, 6)."****";
	}
}

?>