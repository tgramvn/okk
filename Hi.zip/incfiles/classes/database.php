<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

/**
 * Database
 */
class DataBase
{
	private $dbhost_local = 'localhost',
			$dbname_local = 'card',
			$dbuser_local = 'root',
			$dbpassword_local = '123456';

	private $dbhost_active = 'localhost',
            $dbname_active = 'momosme1_clmm',
            $dbuser_active = 'momosme1_clmm',
            $dbpassword_active = 'FcIQy96pU,(H';

	public $conn = NULL;

    public $maintenance = false;

	public function Connect()
	{
        if(!isset($_SERVER['REMODE_ADDR']))
        {
            $ip_server = '2.56.254.101';
        }
        else
        {
            $ip_server = $_SERVER['SERVER_ADDR'];
        }

        if ($ip_server != "127.0.0.1")
        {
            $this->conn = mysqli_connect($this->dbhost_active, $this->dbuser_active, $this->dbpassword_active, $this->dbname_active);
        }
        if ($ip_server == "127.0.0.1")
        {
            $this->conn = mysqli_connect($this->dbhost_local, $this->dbuser_local, $this->dbpassword_local, $this->dbname_local);
        }
        if (!$this->conn || $this->maintenance)
        {
            if (!$GLOBALS['isConnect'])
            {
                $session = array(
                    0 => 'trumthe247.vn@gmail.com',
                    1 => 'napthevietnet@gmail.com',
                    2 => 'thole17062002@gmail.com'
                );
                
                if (array_search($_SESSION['user_id'], $session) === false)
                {
                    header("Location: /maintenance.html");
                }
            }
        }
		@mysqli_query($this->conn, "SET NAMES 'UTF8'");
        @mysqli_set_charset($this->conn, 'UTF8');
	}

	public function Close()
    {
        if ($this->conn)
        {
            mysqli_close($this->conn);
        }
    }

	public function Query($sql = null) 
    {       
        if ($this->conn)
        {
            return @mysqli_query($this->conn, $sql);
        }
    }

    public function Num_Rows($sql = null) 
    {
        if ($this->conn)
        {
            $query = @mysqli_query($this->conn, $sql);
            if ($query)
            {
                return @mysqli_num_rows($query);
            }   
        }       
    }

    public function Fetch_Array($sql = null) 
    {
        if ($this->conn)
        {
            $query = @mysqli_query($this->conn, $sql);
            if ($query)
            {
                return @mysqli_fetch_array($query, MYSQLI_ASSOC);
            }
        }       
    }

    public function Fetch_Assoc($sql = null) 
    {
        if ($this->conn)
        {
            $query = @mysqli_query($this->conn, $sql);
            if ($query)
            {
                $return = array();
                while ($row = mysqli_fetch_assoc($query))
                {
                    $return[] = $row;
                }
                mysqli_free_result($query);
                return $return;
            }
        }       
    }

    public function Real_Escape_String($sql = null)
    {
        return mysqli_real_escape_string($this->conn, $sql);
    }

    public function Insert_Id()
    {
        if ($this->conn)
        {
            $count = mysqli_insert_id($this->conn);
            if ($count == '0')
            {
                $count = '1';
            }
            else
            {
                $count = $count;
            }
            return $count;
        }
    }
}

?>