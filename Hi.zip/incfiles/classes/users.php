<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

/**
 * USERS
 */
class Users
{
	protected $db;

	protected $core;

	public function __construct($conn, $core)
	{
		$this->db = $conn;
		$this->core = $core;
	}

	public function init($input = null)
	{
		return $this->db->Fetch_Array("SELECT * FROM `tb_users` WHERE `username` = '".$input."'");
	}


	public function isLogin($username = null, $password = null)
	{
		if ($this->db->Num_Rows("SELECT * FROM `tb_users` WHERE `username` = '$username' AND `password` = '".md5(md5($password))."'"))
		{
			return true;
		}
		return false;
	}

	public function isMyIpAddress()
	{
		if (!empty($_SERVER['HTTP_CLIENT_IP']))
		{  
			$ip = $_SERVER['HTTP_CLIENT_IP'];  
		}  
		else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
		{  
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
		}  
		else
		{  
			$ip = $_SERVER['REMOTE_ADDR'];  
		}  
		return $ip;  
	}

}
?>