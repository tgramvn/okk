<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

class History
{
	protected $db;
	
	public function __construct($conn)
	{
		$this->db = $conn;
	}

	public function isTransaction($tranId = null)
	{
		return $this->db->Num_Rows("SELECT * FROM `tb_history` WHERE `momo_txn` = '$tranId'");
	}

	public function createTransaction($tranId, $partnerId, $phone, $gameId, $amount, $receive, $comment, $pay_at, $state_at)
	{
		if (!$this->db->Num_Rows("SELECT * FROM `tb_history` WHERE `momo_txn` = '$tranId'"))
		{
			$this->db->Query("INSERT INTO `tb_history` SET
				`momo_txn` = '$tranId',
				`phone_player` = '$partnerId',
				`phone_recv` = '$phone',
				`gameId` = '$gameId',
				`money` = '$amount',
				`bonus` = '$receive',
				`content` = '$comment',
				`created_at` = '".time()."',
				`pay_at` = '$pay_at',
				`stated_at` = '$state_at'");
		}
	}

}

?>