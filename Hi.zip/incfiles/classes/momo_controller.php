<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

require_once (realpath($_SERVER["DOCUMENT_ROOT"]) .'/vendor/autoload.php');

use Carbon\Carbon;

class MomoController
{
	protected $db;

	protected $core;

	protected $momo;

	private $TimeSetup = 900;
	
	public function __construct($conn, $core, $momo)
	{
		$this->db = $conn;
		$this->core = $core;
		$this->momo = $momo;
	}

	public function decodeInfo($data)
	{
		return json_decode(str_replace(PHP_EOL, '\n', $data), true);
	}

    public function resetMomo($phoneNum)
    {
        $this->db->Query("UPDATE `tb_momo` SET `count` = '0', `amountDay` = '0' WHERE `phone` = '$phoneNum'");
    }

    public function resetAllMomo()
    {
        $req_momo = $this->db->Query("SELECT * FROM `tb_private_momo`");
        while ($m_data = mysqli_fetch_array($req_momo))
        {
            $this->db->Query("UPDATE `tb_momo` SET `count` = '0', `amountDay` = '0' WHERE `phone` = '".$m_data['phone']."'");
        }
    }

	public function updateRealTimeMomo($amount = null, $phone = null)
	{
		return $this->db->Query("UPDATE `tb_momo` SET
			`count` = `count` + 1,
			`amountDay` = `amountDay` + '$amount',
			`amountMonth` = `amountMonth` + '$amount' WHERE `phone` = '$phone'");
	}

	public function loginMomo($phone)
	{
		$dataMomo = $this->db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `phone` = '$phone'");
		$data_old = json_decode($dataMomo['info'], true);
		$agent_id = $this->core->addArray($data_old, array('agent_id' => ''));
		$sessionkey = $this->core->addArray($agent_id, array('sessionkey' => ''));
		$data_new = $this->core->addArray($sessionkey, array('authorization' => ''));
		$result = $this->momo->USER_LOGIN_MSG($data_new);
		
		if ($result['errorCode'])
		{
			$this->db->Query("UPDATE `tb_private_momo` SET
				`name` = '".$result['errorDesc']."',
    			`balance` = '0',
				`status` = '4',
				`info` = '".json_encode($data_old)."' WHERE `phone` = '$phone'");

			return array(
				'status' => 'error',
				'message' => 'Thất bại',
				'data' => array(
					'code' => $result['errorCode'],
					'desc' => $result['errorDesc']
				)
			);
		}
		else
		{
			$arr = array(
				'authorization' => $result['extra']['AUTH_TOKEN'],
				'RSA_PUBLIC_KEY' => $result['extra']['REQUEST_ENCRYPT_KEY'],
				'sessionkey' => $result['extra']['SESSION_KEY'],
				'agent_id' => $result['momoMsg']['agentId'],
				'BankVerify' => $result['momoMsg']['bankVerifyPersonalid'],
				'refreshToken' => $result['extra']['REFRESH_TOKEN'],
			);
			$name = $result['momoMsg']['name'];
			$balance = $result['extra']['BALANCE'];
			
			$redata = json_encode($this->core->addArray($data_new, $arr), JSON_UNESCAPED_UNICODE);
			$this->db->Query("UPDATE `tb_momo` SET `name` = '$name' WHERE `phone` = '$phone'");
			$this->db->Query("UPDATE `tb_private_momo` SET
				`name` = '$name',
				`balance` = '$balance',
				`info` = '".$redata."' WHERE `phone` = '$phone'");
			return array(
				'status' => 'success',
				'message' => 'Đăng nhập thành công'
			);
		}
	}

	public function refToken()
    {
    	$momo = $this->db->Fetch_Assoc("SELECT * FROM `tb_private_momo`");
        $data = [];
        $i = 0;
        foreach ($momo as $dataMomo)
        {
            if ($this->TimeSetup < (time() - $dataMomo['time_login']))
            {
                $response = $this->getNewToken($dataMomo['token']);
                $data[$i]['status'] = $response['status'];
                $data[$i]['phone'] = $dataMomo['phone'];
                $data[$i]['message'] = $response['message'];
                $i++;
                $this->db->Query("UPDATE `tb_private_momo` SET `time_login` = '".time()."' WHERE `id` = '".$dataMomo['id']."'");
            }
            else
            {
                $data[$i]['status'] = 'success';
                $data[$i]['phone'] = $dataMomo['phone'];
                $data[$i]['message'] = 'Vui lòng đợi '.($this->TimeSetup - (time() - $dataMomo['time_login'])). ' giây nữa';
                $i++;
            }
        }
        return json_encode(array('author' => 'TRAN_LONG_IT', 'data' => $data));
    }

	public function getNewToken($token)
    {
    	$dataMomo = $this->db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `token` = '$token'");

        if ($dataMomo['try'] == 5)
        {
        	$this->db->Query("UPDATE `tb_private_momo` SET `status` = '4' WHERE `phone` = '".$dataMomo['phone']."'");
            return array('status' => 'error', 'message' => "Lỗi login nhiều lần không được", 'author' => 'TRAN LONG IT');
        }
    	$data = $this->decodeInfo($dataMomo['info']);
        $result = $this->momo->GENERATE_TOKEN_AUTH_MSG($data);

        if ($result['errorCode'] == 0)
        {
        	$authorization = $this->core->addArray($data, array('authorization' => $result['extra']['AUTH_TOKEN']));
			$data_new = $this->core->addArray($authorization, array('RSA_PUBLIC_KEY' => $result['extra']['REQUEST_ENCRYPT_KEY']));

			$this->db->Query("UPDATE `tb_private_momo` SET `info` = '".json_encode($data_new)."' WHERE `phone` = '".$dataMomo['phone']."'");
            return array('status' => 'success', 'message' => 'Thành công', 'author' => 'TRAN LONG IT');
        }
        else
        {
			$this->db->Query("UPDATE `tb_private_momo` SET `try` = `try` + '1' WHERE `phone` = '".$dataMomo['phone']."'");
            return array('status' => 'error', 'message' => $result['errorDesc'], 'author' => 'TRAN LONG IT');
        }
    }

	public function checkMomo($data, $receiver)
	{
		$result = $this->momo->CHECK_USER_PRIVATE($receiver, $data);
		if ($result == null)
		{
			return array('status' => 'error', 'message' => 'Tài khoản không tồn tại hoặc chưa đăng ký momo', 'author' => 'TRAN LONG IT');
		}
		if (!empty($result['errorCode']))
		{
			return array('status' => 'success', 'message' => 'Thành công', 'author' => 'TRAN LONG IT', 'name' => 'Không xác định');
		}
		else
		{
			return array('status' => 'success', 'message' => 'Thành công', 'author' => 'TRAN LONG IT', 'name' => $result['extra']['NAME']);
		}
	}

	// public function historyMomo($token)
 //    {
 //        $dataMomo = $this->db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `token` = '$token'");
 //        $data = $this->decodeInfo($dataMomo['info']);
 //        $result = $this->momo->CheckHisNew(6, $data);
 //        return $result;
 //    }


    public function historyMomo($token)
    {
        $dataMomo = $this->db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `token` = '$token'");
        $data = $this->decodeInfo($dataMomo['info']);
        $from = Carbon::today()->subDay(1)->format('d/m/Y');
        $to = Carbon::today()->format('d/m/Y');
        $limit = 10;
        $result = $this->momo->QUERY_TRAN_HIS_NEW($data, $from, $to, $limit);
        return $result;
    }

    public function historyMomoV2($token)
    {
        $dataMomo = $this->db->Fetch_Array("SELECT * FROM `tb_private_momo` WHERE `token` = '$token'");
        $data = $this->decodeInfo($dataMomo['info']);
        $from = Carbon::today()->subDay(1)->format('d/m/Y');
        $to = Carbon::today()->format('d/m/Y');
        $limit = 20;
        $result = $this->momo->QUERY_TRAN_HIS_NEW($data, $from, $to, $limit);
        return $result;
    }

	public function sendMoneyMomo($dataMomo, $amount, $comment, $receiver)
    {
    	$data = $this->decodeInfo($dataMomo['info']);
    	$name = $this->checkMomo($data, $receiver);
    	if ($name['status'] != 'success')
    	{
    		$json = array(
    			"status" => "error",
    			"code" => -5,
    			"message" => "Đã xảy ra lỗi ở momo hoặc bạn đã hết hạn truy cập vui lòng đăng nhập lại"
    		);
    		return $json;
    	}
    	else
    	{
    		$partnerName = $name['name'];
    	}
    	$dataSend = array(
    		'amount' => (int)$amount,
    		'comment' => $comment,
    		'partnerName' => $partnerName,
    		'receiver' => $receiver,
    	);
    	$result = $this->momo->M2MU_INIT($data, $dataSend);
    	if (!empty($result["errorCode"]) && $result["errorDesc"] != "Lỗi cơ sở dữ liệu. Quý khách vui lòng thử lại sau")
    	{
    		$json = array(
                "status" => "error",
                "code" => $result["errorCode"],
                "message" => $result["errorDesc"]
            );
            return $json;
    	}
    	else if (is_null($result))
    	{
    		$json = array(
                "status" => "error",
                "code" => -5,
                "message" => "Đã xảy ra lỗi ở momo hoặc bạn đã hết hạn truy cập vui lòng đăng nhập lại"
            );
            return $result;
    	}
    	else
    	{
    		$id = $result["momoMsg"]["replyMsgs"]["0"]["ID"];
    		$result = $this->momo->M2MU_CONFIRM($id, $data, $dataSend);
    		if (empty($result['errorCode']))
    		{
    			$balance = $result["extra"]["BALANCE"];
    			$tranHisMsg = $result["momoMsg"]["replyMsgs"]["0"]["tranHisMsg"];

    			$this->db->Query("UPDATE `tb_private_momo` SET
    				`name` = '".$tranHisMsg["ownerName"]."',
    				`balance` = '$balance' WHERE `phone` = '".$dataMomo['phone']."'");

    			$json = array(
    				'status' => 'success',
    				'message' => 'Thành công',
    				'author' => 'TRAN LONG IT',
    				'code' => 0,
    				'data' => array(
    					"balance" => $balance,
    					"ID" => $tranHisMsg["ID"],
    					"tranId" => $tranHisMsg["tranId"],
    					"partnerId" => $tranHisMsg["partnerId"],
    					"partnerName" => $tranHisMsg["partnerName"],
    					"amount" => $tranHisMsg["amount"],
    					"comment" => (empty($tranHisMsg["comment"])) ? "" : $tranHisMsg["comment"],
    					"status" => $tranHisMsg["status"],
    					"desc" => $tranHisMsg["desc"],
    					"ownerNumber" => $tranHisMsg["ownerNumber"],
    					"ownerName" => $tranHisMsg["ownerName"],
    					"millisecond" => $tranHisMsg["finishTime"]
    				)
    			);
    			return $json;
            }
            else
            {
                $json = array(
                    'status' => 'error',
                    'author' => 'TRAN LONG IT',
                    "code" => $result["errorCode"],
                    "message" => $result["errorDesc"]
                );
                return $json;
            }
        }
        return $result;
    }

}

?>