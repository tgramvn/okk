<?php

/**
* @package     MomoCMS
* @link        http://
* @copyright   Copyright (C) 2022-2022 TimoCMS Community
* @author      Tran Long IT
*/

ob_start();
session_start();
error_reporting(-1);
ini_set('display_errors', 'On');
error_reporting(0 & ~E_NOTICE );
header('Access-Control-Allow-Origin: *');
header('Content-Type: text/html;charset=utf-8');
date_default_timezone_set('Asia/Ho_Chi_Minh');
require_once ('classes/database.php');
require_once ('classes/core.php');
require_once ('classes/users.php');
require_once ('classes/momo_api.php');
require_once ('classes/momo_controller.php');
require_once ('classes/history.php');

$db = new DataBase();
$db->Connect();
$core = new Core($db);
$users = new Users($db, $core);
$momo = new MomoAPI($db);
$momo_ctrl = new MomoController($db, $core, $momo);
$momo_history = new History($db);

$user_agent = $_SERVER['HTTP_USER_AGENT'];

if (isset($_SESSION['user_id']) && isset($_SESSION['user_password']))
{
	$account = $_SESSION['user_id'];
}
else
{
	$account = NULL;
}

if ($account != NULL) 
{
	$datauser = $users->init($account);
	$db->Query("UPDATE `tb_users` SET `last_access` = '".time()."', `ip_address` = '".$users->isMyIpAddress()."' WHERE `id` = '".$datauser['id']."'");
	if ($datauser['password'] != $_SESSION['user_password'])
	{
		header("Location: ".$core->isHomeSetting('website_url')."");
	}
}


ob_flush();
?>